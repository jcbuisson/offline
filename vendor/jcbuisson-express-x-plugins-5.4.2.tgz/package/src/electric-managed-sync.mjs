import { withInitialValue } from './electric-query-observable.mjs'
import { Observable } from 'rxjs'

/** One database and one cached model per plugin instance. Browser locks span tabs. */
export function createManagedSync(options, createModel) {
   options = { ...options }
   const databaseName = options.databaseName
   if (typeof databaseName !== 'string' || !databaseName.trim()) {
      throw new TypeError('sync: true requires a non-empty databaseName')
   }
   const locks = options.locks ?? globalThis.navigator?.locks
   const Channel = options.BroadcastChannel ?? globalThis.BroadcastChannel
   if (!locks?.request || !Channel) throw new Error('Managed sync requires Web Locks and BroadcastChannel (use HTTPS or localhost)')
   let database
   let preparation = Promise.resolve()
   let closed = false
   let disposal
   const models = new Map()

   function getDatabase() {
      database ??= Promise.resolve().then(async () => {
         if (options.localDb) return options.localDb
         if (options.createDatabase) return options.createDatabase({ dataDir: `idb://${databaseName}` })
         const { PGliteWorker } = await import('@electric-sql/pglite/worker')
         const worker = options.workerFactory
            ? options.workerFactory()
            : new Worker(new URL('./electric-pglite-worker.mjs', import.meta.url), { type: 'module' })
         let timer
         let rejectFailure
         const failure = new Promise((_, reject) => { rejectFailure = reject })
         const fail = event => rejectFailure(new Error(event.message ?? 'PGlite worker failed to initialize'))
         worker.addEventListener('error', fail)
         worker.addEventListener('messageerror', fail)
         timer = setTimeout(() => rejectFailure(new Error('PGlite worker initialization timed out')), options.initTimeoutMs ?? 30_000)
         try {
            return await Promise.race([PGliteWorker.create(worker, { dataDir: `idb://${databaseName}` }), failure])
         } catch (error) {
            worker.terminate()
            throw error
         } finally {
            clearTimeout(timer)
            worker.removeEventListener('error', fail)
            worker.removeEventListener('messageerror', fail)
         }
      })
      return database
   }

   function model(name, modelOptions) {
      if (closed) throw new Error('Electric sync has been disposed')
      const existing = models.get(name)
      if (existing) {
         if (existing.primaryKey !== (modelOptions.primaryKey ?? 'uid')) throw new TypeError('A cached sync model cannot change primaryKey')
         return existing.api
      }
      modelOptions = { ...modelOptions }
      if (modelOptions.streamOptions) {
         modelOptions.streamOptions = {
            ...modelOptions.streamOptions,
            params: { ...modelOptions.streamOptions.params },
         }
      }
      let active = true
      let disposed = false
      let disposal
      let controller
      let release
      let generation = 0
      let channel
      let offline
      let error = null
      const invocations = new Set()
      const subscribers = new Set()
      const network = modelOptions.network ?? options.network ?? globalThis.navigator
      const networkEvents = options.networkEvents ?? globalThis
      function report(cause) {
         error = cause
         try { (modelOptions.onError ?? options.onError)?.(cause, { modelName: name }) } catch (callbackError) { console.error(callbackError) }
      }
      const ready = getDatabase().then(async db => {
         channel = new Channel(`express-x:${databaseName}:changes`)
         // The sync owner serves every tab, even while its own tab is hidden.
         const streamOptions = {
            ...modelOptions.streamOptions,
            runtimeVisibility: modelOptions.streamOptions?.runtimeVisibility ?? {
               getCurrentState: () => 'visible',
               subscribe: () => () => {},
            },
         }
         offline = createModel(name, { ...modelOptions, streamOptions, network, localDb: db, channel, ownsSync: false, onError: report })
         const prepared = preparation.then(() => offline.prepare())
         preparation = prepared.catch(() => {})
         await prepared
         if (disposed) return offline
         if (active) startOwnership()
         return offline
      })
      // Report initialization failure even when the first consumer only subscribes.
      void ready.catch(report)

      function startOwnership() {
         if (controller || disposed || !active) return
         offline.start()
         if (network?.onLine === false) return
         controller = new AbortController()
         const ownerGeneration = ++generation
         void locks.request(`express-x:${databaseName}:${name}`, { signal: controller.signal }, async () => {
            if (!active || disposed || network?.onLine === false || generation !== ownerGeneration) return
            try {
               offline.setSyncOwner(true)
               await new Promise(resolve => { release = resolve })
            } finally {
               await offline.waitForIdle()
               if (generation === ownerGeneration) { offline.setSyncOwner(false); release = undefined }
            }
         }).finally(() => {
            // A settled request no longer owns or waits for this lock. In
            // particular, a failed request must permit an explicit start retry.
            if (generation === ownerGeneration) controller = undefined
         }).catch(cause => { if (cause.name !== 'AbortError') report(cause) })
      }
      function releaseOwnership() {
         ++generation
         controller?.abort()
         controller = undefined
         release?.()
         release = undefined
         offline?.setSyncOwner(false)
      }
      function stop() {
         active = false
         releaseOwnership()
         offline?.stop()
      }
      function updateNetwork() {
         if (disposed) return
         if (network?.onLine === false) releaseOwnership()
         else if (active) void ready.then(startOwnership).catch(report)
      }
      networkEvents.addEventListener?.('offline', updateNetwork)
      networkEvents.addEventListener?.('online', updateNetwork)
      function start() {
         if (disposed) throw new Error('Electric model has been disposed')
         active = true
         return ready.then(() => startOwnership())
      }
      function invoke(method, ...args) {
         if (disposed) return Promise.reject(new Error('Electric model has been disposed'))
         // Read inputs at invocation time, before initialization can defer execution.
         try { args = structuredClone(args) } catch (cause) { return Promise.reject(cause) }
         const invocation = ready.then(model => model[method](...args)).finally(() => invocations.delete(invocation))
         invocations.add(invocation)
         return invocation
      }
      const api = {
         prepare: () => ready.then(() => undefined), start, stop,
         dispose() {
            if (disposal) return disposal
            disposed = true
            disposal = Promise.resolve().then(async () => {
               for (const subscriber of subscribers) subscriber.complete()
               networkEvents.removeEventListener?.('offline', updateNetwork)
               networkEvents.removeEventListener?.('online', updateNetwork)
               stop()
               try {
                  await ready
                  await Promise.allSettled([...invocations])
                  await offline.waitForIdle()
               } finally { channel?.close(); models.delete(name) }
            })
            return disposal
         },
         getObservable(where = {}, options = {}) {
            const query = structuredClone(where)
            return withInitialValue(new Observable(subscriber => {
               if (disposed) { subscriber.error(new Error('Electric model has been disposed')); return }
               let subscription
               let cancelled = false
               subscribers.add(subscriber)
               const fail = cause => subscriber.error(cause)
               void ready.then(model => {
                  if (!cancelled && !disposed) subscription = model.getObservable(query).subscribe(subscriber)
               }).catch(fail)
               return () => { cancelled = true; subscribers.delete(subscriber); subscription?.unsubscribe() }
            }), options)
         },
         findMany: (where = {}) => invoke('findMany', where),
         findUnique: (where = {}) => invoke('findUnique', where),
         create: data => invoke('create', data),
         update: (id, data) => invoke('update', id, data),
         remove: id => invoke('remove', id),
         flushQueue: () => invoke('flushQueue'),
         getStatus: async () => ({ ...await invoke('getStatus'), error: error?.message ?? null }),
      }
      models.set(name, { api, primaryKey: modelOptions.primaryKey ?? 'uid' })
      return api
   }
   function dispose() {
      if (disposal) return disposal
      closed = true
      disposal = Promise.allSettled([...models.values()].map(({ api }) => api.dispose())).then(async () => {
         if (database && !options.localDb) await (await database).close()
      })
      return disposal
   }
   return { model, dispose }
}
