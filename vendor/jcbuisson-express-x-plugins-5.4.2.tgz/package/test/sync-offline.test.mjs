// Must be imported before Dexie so it patches globalThis.indexedDB first
import 'fake-indexeddb/auto'

import { test, describe, after } from 'node:test'
import assert from 'node:assert/strict'
import { io as ioc } from 'socket.io-client'
import { firstValueFrom } from 'rxjs'
import { effectScope } from 'vue'
import { PGlite } from '@electric-sql/pglite'
import { drizzle } from 'drizzle-orm/pglite'
import { pgTable, text, timestamp, integer } from 'drizzle-orm/pg-core'
import { eq } from 'drizzle-orm'

import { expressX } from '@jcbuisson/express-x/server'
import { computeSyncResult } from '../src/sync-algorithm.mjs'
import { createClient } from '@jcbuisson/express-x/client'
import { offlinePlugin as rawOfflinePlugin } from '../src/sync-client-plugin.mjs'
const offlinePlugin = (app, options = {}) =>
   rawOfflinePlugin(app, { cacheNamespace: 'express-x-tests', ...options })
const localOfflinePlugin = offlinePlugin

import { drizzleOfflinePlugin as rawDrizzleOfflinePlugin } from '../src/sync-server-plugin.mjs'
const allowAll = { authorize: async () => true, computeSyncResult }
const drizzleOfflinePlugin = (app, db, metadata, models, options = {}) =>
   rawDrizzleOfflinePlugin(app, db, metadata, models, { ...allowAll, ...options })
const localDrizzleOfflinePlugin = drizzleOfflinePlugin

const T0 = new Date('2026-01-01T00:00:00Z')
const T1 = new Date('2026-01-02T00:00:00Z')
const T2 = new Date('2026-01-03T00:00:00Z')

let dbCounter = 0

// ─── In-memory DB helper ──────────────────────────────────────────────────────
// Each test gets a fresh PGlite instance with a unique model table so tests
// are fully isolated. Model names use underscores (PG-safe identifiers).

async function createTestDb(modelName) {
   const pglite = new PGlite()
   await pglite.exec(`
      CREATE TABLE metadata (
         uid TEXT PRIMARY KEY,
         created_at TIMESTAMP,
         updated_at TIMESTAMP,
         deleted_at TIMESTAMP
      );
      CREATE TABLE "${modelName}" (
         uid TEXT PRIMARY KEY,
         label TEXT NOT NULL
      );
   `)
   const db = drizzle(pglite)
   const metaTable = pgTable('metadata', {
      uid: text('uid').primaryKey(),
      created_at: timestamp(),
      updated_at: timestamp(),
      deleted_at: timestamp(),
   })
   const modelTable = pgTable(modelName, {
      uid: text('uid').primaryKey(),
      label: text('label').notNull(),
   })
   return { pglite, db, metaTable, modelTable }
}

// ─── Test context helper ──────────────────────────────────────────────────────

async function createTestContext(registerServices, { useOfflinePlugin = false, offlinePluginImpl = offlinePlugin } = {}) {
   const serverApp = expressX({})
   registerServices(serverApp)

   await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
   const port = serverApp.httpServer.address().port

   const socket = ioc(`http://localhost:${port}`, {
      transports: ['websocket'],
      autoConnect: false,
   })

   const clientApp = createClient(socket, { debug: false })
   if (useOfflinePlugin) offlinePluginImpl(clientApp)

   socket.connect()
   await new Promise((resolve, reject) => {
      socket.on('connect', resolve)
      socket.on('connect_error', reject)
   })

   const cleanup = () => new Promise(resolve => {
      socket.disconnect()
      serverApp.io.close(resolve)
   })

   return { clientApp, socket, cleanup }
}

// ─────────────────────────────────────────────────────────────────────────────

describe('Full offline-first client ↔ server protocol', () => {

   test('service call is routed through client-request / client-response', async () => {
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('greet', {
            hello: async (name) => `Hello, ${name}!`,
         })
      })

      try {
         const result = await clientApp.service('greet').hello('World')
         assert.equal(result, 'Hello, World!')
      } finally {
         await cleanup()
      }
   })

   test('prototype-like service and method names are routed safely', async () => {
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('constructor', {
            toString: async () => 'safe',
         })
      })

      try {
         assert.equal(await clientApp.service('constructor').call('toString'), 'safe')
      } finally {
         await cleanup()
      }
   })

   test('malformed client request receives a structured error', async () => {
      const { socket, cleanup } = await createTestContext(() => {})

      try {
         const response = await socket.timeout(1000).emitWithAck('client-request', null)
         assert.equal(response.error?.code, 'invalid-request')
      } finally {
         await cleanup()
      }
   })

   test('duplicate service registration is rejected', () => {
      const serverApp = expressX({})
      serverApp.createService('duplicate', { first: async () => true })
      assert.throws(
         () => serverApp.createService('duplicate', { second: async () => true }),
         /already exists/,
      )
      serverApp.io.close()
   })

   test('server error is propagated to the client as a rejection', async () => {
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('broken', {
            explode: async () => { throw new Error('something went wrong') },
         })
      })

      try {
         await assert.rejects(
            () => clientApp.service('broken').explode(),
            err => {
               assert.match(err.message, /something went wrong/)
               return true
            },
         )
      } finally {
         await cleanup()
      }
   })

   test('client-request without acknowledgment callback does not throw on server error', async () => {
      const { socket, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('broken', {
            explode: async () => { throw new Error('something went wrong') },
         })
      })

      try {
         socket.emit('client-request', {
            name: 'broken',
            action: 'explode',
            args: [],
         })

         await new Promise(resolve => setTimeout(resolve, 20))
         assert.equal(socket.connected, true)
      } finally {
         await cleanup()
      }
   })

   test('sync.go through socket: server records pulled into real Dexie', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'Vacances' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const r1 = await model.db.values.get('r1')
         assert.ok(r1, 'Dexie should contain the record pulled from server via socket')
         assert.equal(r1.label, 'Vacances')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('sync.go through socket: local Dexie record pushed to server', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'x1', label: 'Formation' })
         await model.db.metadata.add({ uid: 'x1', created_at: T1 })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'x1'))
         assert.ok(rows.length > 0, 'server should have received the pushed record')
         assert.equal(rows[0].label, 'Formation')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('record only on client, deleted → ignored on both sides', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'd1', label: 'Gone', __deleted__: true })
         await model.db.metadata.add({ uid: 'd1', created_at: T0, deleted_at: T1 })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const rows = await db.select().from(modelTable)
         assert.ok(!rows.find(r => r.uid === 'd1'), 'server should not have the deleted-only record')
         const d1 = await model.db.values.get('d1')
         assert.ok(!d1, 'Dexie should no longer hold the deleted record')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('newer local tombstone upgrades older server tombstone on sync', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'd1', created_at: T0, deleted_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.metadata.add({ uid: 'd1', created_at: T0, deleted_at: T2, __dirty__: true })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'd1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'server tombstone should be upgraded to newer client tombstone')
         assert.ok(!await model.db.metadata.get('d1'), 'acknowledged local tombstone should be removed')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('create() rollback removes metadata when server rejects', async () => {
      const modelName = `model${++dbCounter}`

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => { throw new Error('server rejected') },
            findMany:        async () => [],
            updateWithMeta:  async () => {},
            deleteWithMeta:  async () => {},
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // create() is optimistic: value + metadata are written to Dexie before the
         // server responds, then rolled back if the server rejects.
         const record = await model.create({ label: 'test' })
         const uid = record.uid

         assert.ok(await model.db.values.get(uid),    'value should exist optimistically')
         assert.ok(await model.db.metadata.get(uid),  'metadata should exist optimistically')

         // Poll until the rollback removes the value (server rejection processed)
         for (let i = 0; i < 50; i++) {
            await new Promise(r => setTimeout(r, 10))
            if (!await model.db.values.get(uid)) break
         }

         assert.ok(!await model.db.values.get(uid),   'value should be removed after rollback')
         // Metadata must also be cleaned up — currently it is not
         assert.ok(!await model.db.metadata.get(uid), 'metadata should also be removed after rollback')
      } finally {
         await cleanup()
      }
   })

   test('deleted record is fully removed from Dexie metadata after sync', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         // Record created and deleted locally before ever reaching the server
         await model.db.values.add({ uid: 'd1', label: 'Gone', __deleted__: true })
         await model.db.metadata.add({ uid: 'd1', created_at: T0, deleted_at: T1 })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const d1 = await model.db.values.get('d1')
         assert.ok(!d1, 'Dexie values should not hold deleted record')

         // Metadata must also be removed — orphaned rows waste space and cause
         // a ConstraintError if a record with the same uid is ever re-created
         const d1Meta = await model.db.metadata.get('d1')
         assert.ok(!d1Meta, 'Dexie metadata should also be removed for deleted record')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('record in both, DB newer → client cache is updated with server value', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      // Server has s1 at T2 (newer than client)
      await db.insert(modelTable).values({ uid: 's1', label: 'server-v2' })
      await db.insert(metaTable).values({ uid: 's1', created_at: T0, updated_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         // Client has s1 at T1 (stale)
         await model.db.values.add({ uid: 's1', label: 'client-v1' })
         await model.db.metadata.add({ uid: 's1', created_at: T0, updated_at: T1 })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const s1 = await model.db.values.get('s1')
         assert.equal(s1.label, 'server-v2', 'client Dexie should be updated with server\'s newer value')

         // A second sync must be a no-op — proves the client timestamp was
         // correctly updated to the server's, avoiding an infinite re-sync loop.
         await model.synchronizeAll()
         const s1Again = await model.db.values.get('s1')
         assert.equal(s1Again.label, 'server-v2', 'second sync should not overwrite client value')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('record in both, DB created_at newer → client metadata is fully replaced', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      // Server is newer by created_at only; updated_at is null.
      await db.insert(modelTable).values({ uid: 's1', label: 'server-created-later' })
      await db.insert(metaTable).values({ uid: 's1', created_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 's1', label: 'client-created-earlier' })
         await model.db.metadata.add({ uid: 's1', created_at: T1 })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const s1 = await model.db.values.get('s1')
         const meta = await model.db.metadata.get('s1')
         assert.equal(s1.label, 'server-created-later')
         assert.equal(new Date(meta.created_at).getTime(), T2.getTime())

         await model.synchronizeAll()
         const s1Again = await model.db.values.get('s1')
         assert.equal(s1Again.label, 'server-created-later')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('one failed updateWithMeta does not abort remaining updateDatabase entries', async () => {
      const modelName = `model${++dbCounter}`
      const serverUpdated = {}

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('sync', {
            // Tell the client both u1 and u2 need to be pushed (client is newer for both)
            go: async (mn, where, clientMetadataDict) => ({
               addClient: [], updateClient: [], deleteClient: [], addDatabase: [],
               updateDatabase: [ clientMetadataDict['u1'], clientMetadataDict['u2'] ],
            }),
         })
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data) => {
               if (uid === 'u1') throw new Error('server rejected u1')
               serverUpdated[uid] = data  // u2 succeeds
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findUnique:     async () => null,
            findMany:       async () => [],
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'u1', label: 'new-u1' })
         await model.db.metadata.add({ uid: 'u1', created_at: T0, updated_at: T2 })
         await model.db.values.add({ uid: 'u2', label: 'new-u2' })
         await model.db.metadata.add({ uid: 'u2', created_at: T0, updated_at: T2 })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         // u2's push must succeed even though u1's updateWithMeta threw
         assert.ok(serverUpdated['u2'], 'u2 should be pushed to server despite u1 failure')
         assert.equal(serverUpdated['u2'].label, 'new-u2')
      } finally {
         await cleanup()
      }
   })

   test('record in both, client newer → server is updated via socket', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'u1', label: 'old' })
      await db.insert(metaTable).values({ uid: 'u1', created_at: T0, updated_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'u1', label: 'new' })
         await model.db.metadata.add({ uid: 'u1', created_at: T0, updated_at: T2 })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'u1'))
         assert.equal(rows[0].label, 'new', 'server should have the updated label')
         const clientValue = await model.db.values.get('u1')
         assert.equal(clientValue.label, 'new', 'client Dexie should be unchanged')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('server tombstone newer than stale client copy deletes client cache on sync', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      // r1 exists on server initially
      await db.insert(modelTable).values({ uid: 'r1', label: 'original' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      // Server-side delete while client was offline: hard-delete from model table,
      // but metadata row stays with deleted_at set (this is what deleteWithMeta does)
      await db.delete(modelTable).where(eq(modelTable.uid, 'r1'))
      await db.update(metaTable).set({ deleted_at: T1 }).where(eq(metaTable.uid, 'r1'))

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         // Client has r1 — it was offline when the server deleted it
         await model.db.values.add({ uid: 'r1', label: 'keep me' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         // Server tombstone is newer than the stale client copy, so the client
         // must delete its cache instead of resurrecting the server row.
         const rows = await db.select().from(modelTable)
         assert.ok(!rows.find(r => r.uid === 'r1'), 'server tombstone should not be recreated by stale client copy')
         const r1 = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')
         assert.ok(!r1, 'client Dexie value should be deleted when server tombstone is newer')
         assert.ok(!meta, 'client Dexie metadata should be deleted when server tombstone is newer')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('server tombstone deletes stale server row and client cache on sync', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'stale-server-row' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'stale-client-row' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'stale server row must be deleted when metadata has a newer tombstone')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T1.getTime())
         assert.ok(!await model.db.values.get('r1'), 'client value should be deleted by server tombstone')
         assert.ok(!await model.db.metadata.get('r1'), 'client metadata should be deleted by server tombstone')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('server tombstone deletes stale server-only row without adding it to client', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'stale-server-row' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'stale server-only row must be deleted when metadata is tombstoned')
         assert.ok(!await model.db.values.get('r1'), 'tombstoned server-only row must not be added to client')
         assert.ok(!await model.db.metadata.get('r1'), 'tombstoned server-only metadata must not be added to client')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('server live metadata without row tombstones stale client cache on sync', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'stale-client-row' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T1 })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'missing server row must stay absent')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'orphaned live server metadata should become a tombstone')
         assert.ok(!await model.db.values.get('r1'), 'client value should be deleted when newer server metadata has no row')
         assert.ok(!await model.db.metadata.get('r1'), 'client metadata should be deleted when newer server metadata has no row')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('newer local tombstone tombstones orphaned live server metadata', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.metadata.add({ uid: 'r1', created_at: T0, deleted_at: T2, __dirty__: true })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'server row must remain absent')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'newer local tombstone should tombstone orphaned server metadata')
         assert.ok(!await model.db.values.get('r1'), 'local value should remain absent')
         assert.ok(!await model.db.metadata.get('r1'), 'acknowledged local tombstone should be cleared')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct update newer than server tombstone re-creates server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'original' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })
      await db.delete(modelTable).where(eq(modelTable.uid, 'r1'))
      await db.update(metaTable).set({ deleted_at: T1 }).where(eq(metaTable.uid, 'r1'))

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'stale-client' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.update('r1', { label: 'client-new' })

         let rows = []
         for (let i = 0; i < 50; i++) {
            rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
            if (rows[0]?.label === 'client-new') break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.equal(rows[0]?.label, 'client-new', 'newer direct client update should recreate server row')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.ok(!serverMeta.deleted_at, 'server tombstone should be cleared after newer direct update')
         assert.equal(new Date(serverMeta.updated_at).getTime() > T1.getTime(), true)

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const clientValue = await model.db.values.get('r1')
         const clientMeta = await model.db.metadata.get('r1')
         assert.equal(clientValue.label, 'client-new', 'sync should not delete the recreated client row')
         assert.ok(!clientMeta.deleted_at, 'client metadata should not keep the old tombstone')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct update with no server row or metadata creates server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'old-local' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, __dirty__: false })

         await model.update('r1', { label: 'client-new' })

         let rows = []
         let clientMeta = null
         for (let i = 0; i < 50; i++) {
            rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
            clientMeta = await model.db.metadata.get('r1')
            if (rows[0]?.label === 'client-new' && clientMeta?.__dirty__ === false) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.equal(rows[0]?.label, 'client-new', 'server row must exist after updateWithMeta')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.ok(serverMeta.updated_at, 'server metadata should record the update timestamp')
         assert.equal(serverMeta.deleted_at, null)
         const clientValue = await model.db.values.get('r1')
         assert.equal(clientValue.label, 'client-new')
         assert.equal(clientMeta.__dirty__, false, 'sync should mark the created server row clean')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct update older than server tombstone deletes stale server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'stale-server-row' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).updateWithMeta('r1', { label: 'client-old' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct update should not return a live row')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T2.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'stale server row must be deleted when tombstone wins')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'server tombstone must not be cleared')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct update older than server update does not overwrite server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'server-new' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).updateWithMeta('r1', { label: 'client-old' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue.label, 'server-new', 'stale direct update should return the newer server row')
         assert.equal(new Date(returnedMeta.updated_at).getTime(), T2.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows[0]?.label, 'server-new', 'server row must survive stale direct update')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.updated_at).getTime(), T2.getTime(), 'server metadata must not be downgraded')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct update equal to server update does not overwrite server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'server-same-time' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).updateWithMeta('r1', { label: 'client-same-time' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue.label, 'server-same-time', 'equal direct update should return the existing server row')
         assert.equal(new Date(returnedMeta.updated_at).getTime(), T1.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows[0]?.label, 'server-same-time', 'equal direct update must not overwrite server row')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.updated_at).getTime(), T1.getTime(), 'server metadata must remain unchanged')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct update older than orphaned server metadata tombstones and removes local row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).updateWithMeta('r1', { label: 'client-old' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct update should not return a row when server metadata is orphaned')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T2.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'orphaned server row must remain absent')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'orphaned live metadata should become a tombstone')

         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T1, __dirty__: true })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         assert.ok(!await model.db.values.get('r1'), 'sync should remove stale local row after orphaned update tombstone')
         assert.ok(!await model.db.metadata.get('r1'), 'sync should remove stale local metadata after orphaned update tombstone')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct delete older than server update does not delete server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'server-new' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).deleteWithMeta('r1', T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue.label, 'server-new', 'stale direct delete should return the newer server row')
         assert.ok(!returnedMeta.deleted_at, 'stale direct delete should not write a tombstone')

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows[0]?.label, 'server-new', 'server row must survive stale direct delete')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.ok(!serverMeta.deleted_at, 'server metadata must not be tombstoned by stale direct delete')
         assert.equal(new Date(serverMeta.updated_at).getTime(), T2.getTime())
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct delete older than server tombstone does not downgrade tombstone', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).deleteWithMeta('r1', T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct delete should not return a deleted server row')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T2.getTime(), 'stale direct delete should return newer tombstone')

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'server row must remain absent')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'server tombstone must not be downgraded')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct delete older than server tombstone removes stale server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'stale-server-row' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).deleteWithMeta('r1', T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct delete should not return a stale row under tombstone metadata')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T2.getTime(), 'stale direct delete should return newer tombstone')

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'server tombstone must delete stale model row')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'server tombstone must not be downgraded')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct delete older than orphaned server metadata tombstones and removes local row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)
      const futureUpdate = new Date(Date.now() + 60_000)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: futureUpdate })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).deleteWithMeta('r1', T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct delete should not return a row when server metadata is orphaned')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), futureUpdate.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'orphaned server row must remain absent')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), futureUpdate.getTime(), 'orphaned live metadata should become a tombstone')

         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })
         await model.remove('r1')

         for (let i = 0; i < 50; i++) {
            if (!await model.db.values.get('r1')) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.ok(!await model.db.values.get('r1'), 'delete acknowledgement tombstone should remove hidden local row')
         assert.ok(!await model.db.metadata.get('r1'), 'delete acknowledgement tombstone should remove local metadata')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct delete acknowledgement ignores value when server returns tombstone', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)
      let resolveDeleteStarted
      let deleteRelease
      const deleteStarted = new Promise(resolve => { resolveDeleteStarted = resolve })
      const deleteCanReturn = new Promise(resolve => { deleteRelease = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            deleteWithMeta: async (uid) => {
               resolveDeleteStarted()
               await deleteCanReturn
               return [{ uid, label: 'stale-server-row' }, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }]
            },
            createWithMeta: async () => {},
            updateWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.remove('r1')
         await deleteStarted
         deleteRelease()

         for (let i = 0; i < 50; i++) {
            const value = await model.db.values.get('r1')
            const meta = await model.db.metadata.get('r1')
            if (!value && !meta) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.ok(!await model.db.values.get('r1'), 'tombstone delete acknowledgement should remove value even if a value is returned')
         assert.ok(!await model.db.metadata.get('r1'), 'tombstone delete acknowledgement should remove metadata even if a value is returned')
      } finally {
         await cleanup()
      }
   })

   test('direct delete acknowledgement restores client when server row is newer', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)
      const futureUpdate = new Date(Date.now() + 60_000)

      await db.insert(modelTable).values({ uid: 'r1', label: 'server-new' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: futureUpdate })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.remove('r1')

         let value
         for (let i = 0; i < 50; i++) {
            value = await model.db.values.get('r1')
            if (value?.label === 'server-new' && !value.__deleted__) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         const meta = await model.db.metadata.get('r1')
         assert.equal(value?.label, 'server-new', 'client should restore newer server row after stale delete acknowledgement')
         assert.ok(!value.__deleted__, 'client restored row must not remain hidden')
         assert.ok(!meta.deleted_at, 'client metadata must not keep stale delete timestamp')
         assert.equal(new Date(meta.updated_at).getTime(), futureUpdate.getTime())
         assert.equal(meta.__dirty__, false)
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct create older than server update does not overwrite server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'server-new' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).createWithMeta('r1', { label: 'client-old' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue.label, 'server-new', 'stale direct create should return the newer server row')
         assert.equal(new Date(returnedMeta.updated_at).getTime(), T2.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows[0]?.label, 'server-new', 'server row must survive stale direct create')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.updated_at).getTime(), T2.getTime())
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct create older than orphaned server metadata tombstones and removes optimistic row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, updated_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).createWithMeta('r1', { label: 'client-old' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct create should not return a row when server metadata is orphaned')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T2.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'orphaned server row must remain absent')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime(), 'orphaned live metadata should become a tombstone')

         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T1, __dirty__: true })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         assert.ok(!await model.db.values.get('r1'), 'sync should remove optimistic row after orphaned metadata tombstone')
         assert.ok(!await model.db.metadata.get('r1'), 'sync should remove optimistic metadata after orphaned metadata tombstone')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct create older than server tombstone does not recreate server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).createWithMeta('r1', { label: 'client-old' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct create should not return a recreated row')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T2.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'server tombstone must survive stale direct create')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T2.getTime())
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct create older than server tombstone removes stale server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'stale-server-row' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).createWithMeta('r1', { label: 'client-old' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'stale direct create should not return a stale row under tombstone metadata')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T2.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'server tombstone must delete stale model row')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct create equal to server tombstone does not recreate server row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const result = await clientApp.service(modelName).createWithMeta('r1', { label: 'client-equal' }, T1)
         const [returnedValue, returnedMeta] = result

         assert.equal(returnedValue == null, true, 'equal direct create should not return a recreated row')
         assert.equal(new Date(returnedMeta.deleted_at).getTime(), T1.getTime())

         const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(rows.length, 0, 'server tombstone must survive equal direct create')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T1.getTime())
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('direct create acknowledgement removes optimistic row when server returns tombstone', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)
      let resolveCreateStarted
      let createRelease
      const createStarted = new Promise(resolve => { resolveCreateStarted = resolve })
      const createCanReturn = new Promise(resolve => { createRelease = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async (uid) => {
               resolveCreateStarted()
               await createCanReturn
               return [null, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }]
            },
            updateWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         const record = await model.create({ label: 'client-old' })
         await createStarted
         createRelease()

         for (let i = 0; i < 50; i++) {
            const value = await model.db.values.get(record.uid)
            const meta = await model.db.metadata.get(record.uid)
            if (!value && !meta) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.ok(!await model.db.values.get(record.uid), 'optimistic create value should be removed when server returns tombstone')
         assert.ok(!await model.db.metadata.get(record.uid), 'optimistic create metadata should be removed when server returns tombstone')
      } finally {
         await cleanup()
      }
   })

   test('direct create acknowledgement ignores value when server returns tombstone', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)
      let resolveCreateStarted
      let createRelease
      const createStarted = new Promise(resolve => { resolveCreateStarted = resolve })
      const createCanReturn = new Promise(resolve => { createRelease = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async (uid, data) => {
               resolveCreateStarted()
               await createCanReturn
               return [{ uid, ...data }, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }]
            },
            updateWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         const record = await model.create({ label: 'client-old' })
         await createStarted
         createRelease()

         for (let i = 0; i < 50; i++) {
            const value = await model.db.values.get(record.uid)
            const meta = await model.db.metadata.get(record.uid)
            if (!value && !meta) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.ok(!await model.db.values.get(record.uid), 'tombstone acknowledgement should remove value even if a value is returned')
         assert.ok(!await model.db.metadata.get(record.uid), 'tombstone acknowledgement should remove metadata even if a value is returned')
      } finally {
         await cleanup()
      }
   })

   test('sync addDatabase tombstone response removes optimistic local row', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async (uid) => [null, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }],
            updateWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [clientMetadataDict.r1],
               updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         assert.ok(!await model.db.values.get('r1'), 'sync addDatabase tombstone response should remove local value')
         assert.ok(!await model.db.metadata.get('r1'), 'sync addDatabase tombstone response should remove local metadata')
      } finally {
         await cleanup()
      }
   })

   test('sync addDatabase tombstone response ignores returned value', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async (uid) => [{ uid, label: 'stale-server-row' }, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }],
            updateWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [clientMetadataDict.r1],
               updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         assert.ok(!await model.db.values.get('r1'), 'sync addDatabase tombstone response should remove local value even if a value is returned')
         assert.ok(!await model.db.metadata.get('r1'), 'sync addDatabase tombstone response should remove local metadata even if a value is returned')
      } finally {
         await cleanup()
      }
   })

   test('sync addDatabase live response replaces stale local value', async () => {
      const modelName = `model${++dbCounter}`

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async (uid) => [
               { uid, label: 'server-new' },
               { uid, created_at: T0, updated_at: T2, deleted_at: null },
            ],
            updateWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [clientMetadataDict.r1],
               updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')
         assert.equal(value.label, 'server-new', 'sync addDatabase live response should replace stale local value')
         assert.equal(new Date(meta.updated_at).getTime(), T2.getTime())
         assert.equal(meta.__dirty__, false)
      } finally {
         await cleanup()
      }
   })

   test('direct update acknowledgement removes local row when server returns tombstone', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)
      let resolveUpdateStarted
      let updateRelease
      const updateStarted = new Promise(resolve => { resolveUpdateStarted = resolve })
      const updateCanReturn = new Promise(resolve => { updateRelease = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => {},
            updateWithMeta: async (uid) => {
               resolveUpdateStarted()
               await updateCanReturn
               return [null, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }]
            },
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.update('r1', { label: 'client-new' })
         await updateStarted
         updateRelease()

         for (let i = 0; i < 50; i++) {
            const value = await model.db.values.get('r1')
            const meta = await model.db.metadata.get('r1')
            if (!value && !meta) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.ok(!await model.db.values.get('r1'), 'stale update tombstone response should remove local value')
         assert.ok(!await model.db.metadata.get('r1'), 'stale update tombstone response should remove local metadata')
      } finally {
         await cleanup()
      }
   })

   test('direct update acknowledgement ignores value when server returns tombstone', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)
      let resolveUpdateStarted
      let updateRelease
      const updateStarted = new Promise(resolve => { resolveUpdateStarted = resolve })
      const updateCanReturn = new Promise(resolve => { updateRelease = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => {},
            updateWithMeta: async (uid, data) => {
               resolveUpdateStarted()
               await updateCanReturn
               return [{ uid, ...data }, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }]
            },
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.update('r1', { label: 'client-new' })
         await updateStarted
         updateRelease()

         for (let i = 0; i < 50; i++) {
            const value = await model.db.values.get('r1')
            const meta = await model.db.metadata.get('r1')
            if (!value && !meta) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.ok(!await model.db.values.get('r1'), 'tombstone update acknowledgement should remove value even if a value is returned')
         assert.ok(!await model.db.metadata.get('r1'), 'tombstone update acknowledgement should remove metadata even if a value is returned')
      } finally {
         await cleanup()
      }
   })

   test('sync updateDatabase tombstone response removes local row', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => {},
            updateWithMeta: async (uid) => [null, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }],
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [],
               updateDatabase: [clientMetadataDict.r1],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         assert.ok(!await model.db.values.get('r1'), 'sync updateDatabase tombstone response should remove local value')
         assert.ok(!await model.db.metadata.get('r1'), 'sync updateDatabase tombstone response should remove local metadata')
      } finally {
         await cleanup()
      }
   })

   test('sync updateDatabase tombstone response ignores returned value', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => {},
            updateWithMeta: async (uid) => [{ uid, label: 'stale-server-row' }, { uid, created_at: T0, updated_at: null, deleted_at: futureDelete }],
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [],
               updateDatabase: [clientMetadataDict.r1],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         assert.ok(!await model.db.values.get('r1'), 'sync updateDatabase tombstone response should remove local value even if a value is returned')
         assert.ok(!await model.db.metadata.get('r1'), 'sync updateDatabase tombstone response should remove local metadata even if a value is returned')
      } finally {
         await cleanup()
      }
   })

   test('sync updateDatabase live response replaces stale local value', async () => {
      const modelName = `model${++dbCounter}`

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => {},
            updateWithMeta: async (uid) => [
               { uid, label: 'server-new' },
               { uid, created_at: T0, updated_at: T2, deleted_at: null },
            ],
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [],
               updateDatabase: [clientMetadataDict.r1],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'client-old' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')
         assert.equal(value.label, 'server-new', 'sync updateDatabase live response should replace stale local value')
         assert.equal(new Date(meta.updated_at).getTime(), T2.getTime())
         assert.equal(meta.__dirty__, false)
      } finally {
         await cleanup()
      }
   })

   test('offline changes are synced after server restart', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      // ─ Phase 1: start server, connect, register synchro scope ─
      const serverApp1 = expressX({})
      serverApp1.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])
      await new Promise(resolve => serverApp1.httpServer.listen(0, resolve))
      const port = serverApp1.httpServer.address().port

      const socket = ioc(`http://localhost:${port}`, {
         transports: ['websocket'],
         autoConnect: false,
         reconnectionDelay: 100,
         reconnectionDelayMax: 500,
      })
      const clientApp = createClient(socket, { debug: false })
      offlinePlugin(clientApp)
      socket.connect()
      await new Promise((resolve, reject) => {
         socket.on('connect', resolve)
         socket.on('connect_error', reject)
      })

      const model = clientApp.createOfflineModel(modelName, ['label'])
      await model.addSynchroWhere({})
      await model.synchronizeAll() // initial sync — server is empty

      // ─ Phase 2: stop server; disconnect all clients ─
      // io.disconnectSockets() gives 'io server disconnect' which suppresses
      // socket.io auto-reconnect, so we reconnect manually in phase 5.
      const disconnected = new Promise(resolve => socket.once('disconnect', resolve))
      serverApp1.io.disconnectSockets(true)
      await new Promise(resolve => serverApp1.io.close(resolve))
      await disconnected

      assert.equal(clientApp.isConnected, false, 'client should be offline')

      // ─ Phase 3: write to Dexie while offline ─
      await model.db.values.add({ uid: 'y1', label: 'Offline change' })
      await model.db.metadata.add({ uid: 'y1', created_at: T1 })

      // ─ Phase 4: restart server on the same port ─
      const serverApp2 = expressX({})
      serverApp2.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])
      await new Promise(resolve => serverApp2.httpServer.listen(port, resolve))

      // ─ Phase 5: reconnect manually (auto-reconnect is suppressed after
      // server-initiated disconnect) and wait for offlinePlugin to fire ─
      const reconnected = new Promise((resolve, reject) => {
         const timer = setTimeout(() => reject(new Error('reconnect timeout')), 5000)
         socket.once('connect', () => { clearTimeout(timer); resolve() })
      })
      socket.connect()
      await reconnected

      // ─ Phase 6: offlinePlugin's connect listener fires synchronizeAll in the
      // background; awaiting it here serialises behind the mutex so assertions
      // run only after the offline change has been pushed to the server. ─
      await model.synchronizeAll()

      // ─ Phase 7: assert ─
      assert.equal(clientApp.isConnected, true, 'client should be online again')
      const rows = await db.select().from(modelTable).where(eq(modelTable.uid, 'y1'))
      assert.ok(rows.length > 0, 'offline change should reach the server after reconnect')
      assert.equal(rows[0].label, 'Offline change')

      socket.disconnect()
      await new Promise(resolve => serverApp2.io.close(resolve))
      pglite.close()
   })

   test('reconnect keeps disconnectedDate until automatic sync completes', async () => {
      const modelName = `model${++dbCounter}`
      const serverRows = []
      let resolveSyncStarted
      let releaseSync
      let resolveCreate
      const syncStarted = new Promise(resolve => { resolveSyncStarted = resolve })
      const syncRelease = new Promise(resolve => { releaseSync = resolve })
      const createDone = new Promise(resolve => { resolveCreate = resolve })

      function registerServices(app, { slowSync = false } = {}) {
         app.createService(modelName, {
            createWithMeta: async (uid, data, created_at) => {
               serverRows.push({ uid, ...data })
               resolveCreate()
               return [{ uid, ...data }, { uid, created_at, updated_at: null, deleted_at: null }]
            },
            updateWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         app.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => {
               if (slowSync) {
                  resolveSyncStarted()
                  await syncRelease
               }
               return {
                  addClient: [],
                  updateClient: [],
                  deleteClient: [],
                  addDatabase: Object.values(clientMetadataDict),
                  updateDatabase: [],
               }
            },
         })
      }

      const serverApp1 = expressX({})
      registerServices(serverApp1)
      await new Promise(resolve => serverApp1.httpServer.listen(0, resolve))
      const port = serverApp1.httpServer.address().port

      const socket = ioc(`http://localhost:${port}`, {
         transports: ['websocket'],
         autoConnect: false,
      })
      const clientApp = createClient(socket, { debug: false })
      offlinePlugin(clientApp)
      socket.connect()
      await new Promise((resolve, reject) => {
         socket.on('connect', resolve)
         socket.on('connect_error', reject)
      })

      const model = clientApp.createOfflineModel(modelName, ['label'])
      await model.addSynchroWhere({})
      await model.synchronizeAll()

      const disconnected = new Promise(resolve => socket.once('disconnect', resolve))
      serverApp1.io.disconnectSockets(true)
      await new Promise(resolve => serverApp1.io.close(resolve))
      await disconnected

      await model.db.values.add({ uid: 'reconnect-1', label: 'from reconnect' })
      await model.db.metadata.add({ uid: 'reconnect-1', created_at: T1 })

      const serverApp2 = expressX({})
      registerServices(serverApp2, { slowSync: true })
      await new Promise(resolve => serverApp2.httpServer.listen(port, resolve))

      const reconnected = new Promise((resolve, reject) => {
         const timer = setTimeout(() => reject(new Error('reconnect timeout')), 5000)
         socket.once('connect', () => { clearTimeout(timer); resolve() })
      })
      socket.connect()
      await reconnected
      await syncStarted

      assert.ok(clientApp.disconnectedDate, 'disconnect marker should remain while reconnect sync is running')
      assert.equal(serverRows.length, 0, 'offline row should not be pushed before sync is released')

      releaseSync()
      await createDone

      for (let i = 0; i < 50 && clientApp.disconnectedDate; i++) {
         await new Promise(resolve => setTimeout(resolve, 10))
      }

      assert.equal(clientApp.disconnectedDate, null, 'disconnect marker should clear after reconnect sync completes')
      assert.deepEqual(serverRows, [{ uid: 'reconnect-1', label: 'from reconnect' }])

      socket.disconnect()
      await new Promise(resolve => serverApp2.io.close(resolve))
   })

   test('updateWithMeta pub/sub handler tolerates undefined value (concurrent delete race)', async () => {
      // updateWithMeta does `const [value] = UPDATE ... RETURNING`.  If the model row
      // was deleted by a concurrent operation between the sync's findMany snapshot and
      // the actual UPDATE, RETURNING yields 0 rows → value = undefined.  The server
      // broadcasts [undefined, meta].  The handler crashes on `db.values.put(undefined)`
      // (TypeError: Cannot read properties of undefined) before db.metadata.put(meta)
      // can run, leaving metadata inconsistent.
      const modelName = `model${++dbCounter}`

      const serverApp = expressX({})
      serverApp.addConnectListener(socket => serverApp.joinChannel('all', socket))
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      function connectClient() {
         const socket = ioc(`http://localhost:${port}`, { transports: ['websocket'], autoConnect: false })
         const app = createClient(socket, { debug: false })
         offlinePlugin(app)
         socket.connect()
         return new Promise((resolve, reject) => {
            socket.on('connect', () => resolve({ app, socket }))
            socket.on('connect_error', reject)
         })
      }

      const { app: appB, socket: socketB } = await connectClient()
      const modelB = appB.createOfflineModel(modelName, ['label'])

      await modelB.db.values.add({ uid: 'r1', label: 'old' })
      await modelB.db.metadata.add({ uid: 'r1', created_at: T0 })

      // Simulate the server broadcasting updateWithMeta with undefined value
      serverApp.io.to('all').emit('service-event', {
         name: modelName,
         action: 'updateWithMeta',
         result: [undefined, { uid: 'r1', created_at: T0, updated_at: T1, deleted_at: null }],
      })

      await new Promise(r => setTimeout(r, 200))

      // With bug:  TypeError on undefined crashes before db.metadata.put(meta) runs
      //            → updated_at stays T0 (unchanged).
      // With fix:  handler guards value, skips the put, still updates metadata
      //            → updated_at becomes T1.
      const meta = await modelB.db.metadata.get('r1')
      assert.ok(meta?.updated_at, 'metadata updated_at must be set even when value is undefined')

      socketB.disconnect()
      await new Promise(resolve => serverApp.io.close(resolve))
   })

   test('createWithMeta pub/sub tombstone response removes local row', async () => {
      const modelName = `model${++dbCounter}`

      const serverApp = expressX({})
      serverApp.addConnectListener(socket => serverApp.joinChannel('all', socket))
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      function connectClient() {
         const socket = ioc(`http://localhost:${port}`, { transports: ['websocket'], autoConnect: false })
         const app = createClient(socket, { debug: false })
         offlinePlugin(app)
         socket.connect()
         return new Promise((resolve, reject) => {
            socket.on('connect', () => resolve({ app, socket }))
            socket.on('connect_error', reject)
         })
      }

      const { app: appB, socket: socketB } = await connectClient()
      const modelB = appB.createOfflineModel(modelName, ['label'])

      await modelB.db.values.add({ uid: 'r1', label: 'old' })
      await modelB.db.metadata.add({ uid: 'r1', created_at: T0 })

      serverApp.io.to('all').emit('service-event', {
         name: modelName,
         action: 'createWithMeta',
         result: [undefined, { uid: 'r1', created_at: T0, updated_at: null, deleted_at: T1 }],
      })

      await new Promise(r => setTimeout(r, 200))

      assert.ok(!await modelB.db.values.get('r1'), 'pub/sub create tombstone should remove local value')
      assert.ok(!await modelB.db.metadata.get('r1'), 'pub/sub create tombstone should remove local metadata')

      socketB.disconnect()
      await new Promise(resolve => serverApp.io.close(resolve))
   })

   test('updateWithMeta pub/sub tombstone response removes local row', async () => {
      const modelName = `model${++dbCounter}`

      const serverApp = expressX({})
      serverApp.addConnectListener(socket => serverApp.joinChannel('all', socket))
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      function connectClient() {
         const socket = ioc(`http://localhost:${port}`, { transports: ['websocket'], autoConnect: false })
         const app = createClient(socket, { debug: false })
         offlinePlugin(app)
         socket.connect()
         return new Promise((resolve, reject) => {
            socket.on('connect', () => resolve({ app, socket }))
            socket.on('connect_error', reject)
         })
      }

      const { app: appB, socket: socketB } = await connectClient()
      const modelB = appB.createOfflineModel(modelName, ['label'])

      await modelB.db.values.add({ uid: 'r1', label: 'old' })
      await modelB.db.metadata.add({ uid: 'r1', created_at: T0 })

      serverApp.io.to('all').emit('service-event', {
         name: modelName,
         action: 'updateWithMeta',
         result: [undefined, { uid: 'r1', created_at: T0, updated_at: null, deleted_at: T1 }],
      })

      await new Promise(r => setTimeout(r, 200))

      assert.ok(!await modelB.db.values.get('r1'), 'pub/sub update tombstone should remove local value')
      assert.ok(!await modelB.db.metadata.get('r1'), 'pub/sub update tombstone should remove local metadata')

      socketB.disconnect()
      await new Promise(resolve => serverApp.io.close(resolve))
   })

   test('stale pub/sub events do not overwrite newer dirty local state', async () => {
      const modelName = `model${++dbCounter}`

      const serverApp = expressX({})
      serverApp.addConnectListener(socket => serverApp.joinChannel('all', socket))
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      function connectClient() {
         const socket = ioc(`http://localhost:${port}`, { transports: ['websocket'], autoConnect: false })
         const app = createClient(socket, { debug: false })
         offlinePlugin(app)
         socket.connect()
         return new Promise((resolve, reject) => {
            socket.on('connect', () => resolve({ app, socket }))
            socket.on('connect_error', reject)
         })
      }

      const { app: appB, socket: socketB } = await connectClient()
      const modelB = appB.createOfflineModel(modelName, ['label'])

      await modelB.db.values.add({ uid: 'r1', label: 'local-new' })
      await modelB.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T2, __dirty__: true })

      serverApp.io.to('all').emit('service-event', {
         name: modelName,
         action: 'updateWithMeta',
         result: [{ uid: 'r1', label: 'server-old' }, { uid: 'r1', created_at: T0, updated_at: T1, deleted_at: null }],
      })

      await new Promise(r => setTimeout(r, 100))

      serverApp.io.to('all').emit('service-event', {
         name: modelName,
         action: 'deleteWithMeta',
         result: [{ uid: 'r1', label: 'server-old' }, { uid: 'r1', created_at: T0, updated_at: null, deleted_at: T1 }],
      })

      await new Promise(r => setTimeout(r, 100))

      const value = await modelB.db.values.get('r1')
      const meta = await modelB.db.metadata.get('r1')
      assert.equal(value?.label, 'local-new', 'stale pub/sub update/delete must not overwrite newer dirty value')
      assert.equal(new Date(meta?.updated_at).getTime(), T2.getTime(), 'stale pub/sub event must not downgrade metadata')
      assert.equal(meta?.__dirty__, true, 'dirty marker must survive stale pub/sub event')

      socketB.disconnect()
      await new Promise(resolve => serverApp.io.close(resolve))
   })

   test('deleteWithMeta pub/sub handler uses delete not put to avoid orphan metadata', async () => {
      // synchronize() step 2 deletes both idbValues and idbMetadata for deleteClient uids.
      // The deleteWithMeta pub/sub event may arrive on the SAME tab either before or after
      // that cleanup.  The handler uses db.metadata.put(meta) (upsert with deleted_at),
      // so if it runs AFTER step 2 it RE-CREATES the metadata row as an orphan that can
      // never be cleaned up.  Fix: delete the metadata instead of putting it.
      const modelName = `model${++dbCounter}`

      const serverApp = expressX({})
      serverApp.addConnectListener(socket => serverApp.joinChannel('all', socket))
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      function connectClient() {
         const socket = ioc(`http://localhost:${port}`, { transports: ['websocket'], autoConnect: false })
         const app = createClient(socket, { debug: false })
         offlinePlugin(app)
         socket.connect()
         return new Promise((resolve, reject) => {
            socket.on('connect', () => resolve({ app, socket }))
            socket.on('connect_error', reject)
         })
      }

      const { app: appB, socket: socketB } = await connectClient()
      const modelB = appB.createOfflineModel(modelName, ['label'])

      // r1 exists in client B's Dexie
      await modelB.db.values.add({ uid: 'r1', label: 'test' })
      await modelB.db.metadata.add({ uid: 'r1', created_at: T0 })

      // Simulate step 2 running first (synchronize already cleaned up r1)
      await modelB.db.values.delete('r1')
      await modelB.db.metadata.delete('r1')

      // Pub/sub arrives AFTER step 2 — handler must not re-create metadata as an orphan
      serverApp.io.to('all').emit('service-event', {
         name: modelName,
         action: 'deleteWithMeta',
         result: [{ uid: 'r1', label: 'test' }, { uid: 'r1', created_at: T0, updated_at: null, deleted_at: T1 }],
      })

      await new Promise(r => setTimeout(r, 200))

      // With bug:  put(meta) re-creates metadata with deleted_at → orphan persists
      // With fix:  delete(uid) is a no-op → no orphan
      const orphan = await modelB.db.metadata.get('r1')
      assert.ok(!orphan, 'pub/sub handler must not leave an orphan metadata row after step-2 cleanup')

      socketB.disconnect()
      await new Promise(resolve => serverApp.io.close(resolve))
   })

   test('deleteWithMeta pub/sub handler tolerates undefined value (double-delete race)', async () => {
      // deleteWithMeta does `const [value] = DELETE ... RETURNING`.  When the record
      // is already gone (double-delete race now possible with pub/sub enabled) the
      // RETURNING clause yields 0 rows → value = undefined.  The server then broadcasts
      // [undefined, meta].  The handler crashes on `undefined.uid` (TypeError) before
      // db.metadata.put(meta) runs, leaving other tabs' caches inconsistent.
      const modelName = `model${++dbCounter}`

      const serverApp = expressX({})
      serverApp.addConnectListener(socket => serverApp.joinChannel('all', socket))
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      function connectClient() {
         const socket = ioc(`http://localhost:${port}`, { transports: ['websocket'], autoConnect: false })
         const app = createClient(socket, { debug: false })
         offlinePlugin(app)
         socket.connect()
         return new Promise((resolve, reject) => {
            socket.on('connect', () => resolve({ app, socket }))
            socket.on('connect_error', reject)
         })
      }

      const { app: appB, socket: socketB } = await connectClient()
      const modelB = appB.createOfflineModel(modelName, ['label'])

      // Pre-populate so we can verify the metadata gets the server's deleted_at
      await modelB.db.values.add({ uid: 'r1', label: 'existing' })
      await modelB.db.metadata.add({ uid: 'r1', created_at: T0 })

      // Simulate the server broadcasting deleteWithMeta with undefined value
      // (what happens when the DELETE RETURNING yields 0 rows)
      serverApp.io.to('all').emit('service-event', {
         name: modelName,
         action: 'deleteWithMeta',
         result: [undefined, { uid: 'r1', created_at: T0, updated_at: null, deleted_at: T1 }],
      })

      await new Promise(r => setTimeout(r, 200))

      // With original bug:  TypeError on undefined.uid aborts before db.metadata.*
      //                     runs at all → r1 metadata stays unchanged.
      // With delete fix:    handler guards value, then deletes the metadata row
      //                     → r1 metadata is gone (no orphan, clean state).
      const meta = await modelB.db.metadata.get('r1')
      assert.ok(!meta, 'metadata must be removed even when value is undefined')

      socketB.disconnect()
      await new Promise(resolve => serverApp.io.close(resolve))
   })

   test('update() rollback only restores updated_at, not deleted_at set by a concurrent remove()', async () => {
      // The optimistic write in update() only touches updated_at.  The rollback on
      // server rejection spreads the full previousMetadata snapshot — including
      // deleted_at: null — overwriting any deleted_at that remove() set while the
      // socket round-trip was in flight.  Only updated_at should be restored.
      const modelName = `model${++dbCounter}`

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         // updateWithMeta delays then rejects so remove() can run in the gap
         serverApp.createService(modelName, {
            updateWithMeta: async () => { await new Promise(r => setTimeout(r, 100)); throw new Error('rejected') },
            deleteWithMeta: async () => {},
            createWithMeta: async () => {},
            findMany:        async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         // Explicitly store deleted_at: null (simulates what remove() rollback leaves
         // behind).  Dexie stores the key so previousMetadata includes it, and the
         // rollback then spreads it back — wiping any concurrent remove()'s value.
         await model.db.metadata.add({ uid: 'r1', created_at: T0, deleted_at: null })

         // Fire update() — server will delay 100 ms then reject
         model.update('r1', { label: 'updated' })

         // While updateWithMeta is in flight, remove() sets deleted_at
         await model.remove('r1')

         // Wait for the rejection and rollback to complete
         await new Promise(r => setTimeout(r, 300))

         // deleted_at must survive the update() rollback
         const meta = await model.db.metadata.get('r1')
         assert.ok(meta?.deleted_at, 'deleted_at set by remove() must not be cleared by update() rollback')
      } finally {
         await cleanup()
      }
   })

   test('addClient uses put (upsert) so a concurrent create does not cause ConstraintError', async () => {
      // create() adds a uid to Dexie between synchronize()'s idbValues.filter snapshot
      // and the addClient step.  Because the uid missed the snapshot it is absent from
      // clientMetadataDict, so the server puts it in addClient.  idbValues.add() then
      // throws ConstraintError which aborts the entire transaction, silently dropping all
      // other addClient records in the same batch.
      // Fix: use idbValues.put() (upsert) so a pre-existing uid is handled gracefully.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'server-r1' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })
      await db.insert(modelTable).values({ uid: 'r2', label: 'server-r2' })
      await db.insert(metaTable).values({ uid: 'r2', created_at: T0 })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         // Custom sync that always returns BOTH r1 and r2 in addClient,
         // regardless of what the client already has — simulating the race where
         // r1 was added to Dexie after the clientMetadataDict snapshot.
         serverApp.createService('sync', {
            go: async () => ({
               addClient: [
                  [{ uid: 'r1', label: 'server-r1' }, { uid: 'r1', created_at: T0, updated_at: null, deleted_at: null }],
                  [{ uid: 'r2', label: 'server-r2' }, { uid: 'r2', created_at: T0, updated_at: null, deleted_at: null }],
               ],
               updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // r1 is already in Dexie (simulates what create() does concurrently)
         await model.db.values.add({ uid: 'r1', label: 'client-r1' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         // r2 must still be in Dexie even though r1 caused a uid conflict —
         // the put() upsert must not abort the whole transaction
         const r2 = await model.db.values.get('r2')
         assert.ok(r2, 'r2 must be added despite r1 already existing in Dexie')
         assert.equal(r2.label, 'server-r2')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('missing server metadata does not cause infinite updateClient loop', async () => {
      // When a record exists in the model table but has no metadata row,
      // computeSyncResult falls back to { uid, created_at: new Date() }.
      // new Date() is always "now", so databaseUpdatedAt > clientUpdatedAt forever →
      // updateClient fires on every sync even though nothing changed.
      // Fix: use null instead of new Date() so the client's version "wins" once
      // (updateDatabase), the server gets metadata, and subsequent syncs see diff=0.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      // Server has s1 in model table but intentionally NO metadata row
      await db.insert(modelTable).values({ uid: 's1', label: 'server-label' })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         // Client has s1 with its own timestamp
         await model.db.values.add({ uid: 's1', label: 'client-label' })
         await model.db.metadata.add({ uid: 's1', created_at: T0 })
         await model.addSynchroWhere({})

         // First sync
         await model.synchronizeAll()

         // Second sync — with the bug, updateClient fires again (infinite loop);
         // with the fix the second sync is a no-op (client pushed its data, diff=0)
         let secondSyncUpdateClientCount = 0
         const origUpdateWithMeta = db  // just a marker — we measure via server state

         await model.synchronizeAll()

         // After two syncs the server metadata must now exist (created by updateWithMeta
         // on the first sync) so a third sync should be a true no-op
         const metaRows = await db.select().from(metaTable)
         const s1Meta = metaRows.find(r => r.uid === 's1')
         assert.ok(s1Meta, 'server metadata must be created after the first sync (updateDatabase + upsert)')
         assert.ok(
            s1Meta.created_at || s1Meta.updated_at || s1Meta.deleted_at,
            'repaired server metadata must contain a usable timestamp',
         )
         assert.equal((await model.db.metadata.get('s1')).__dirty__, false, 'repaired local metadata should be clean')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('server-only row with missing metadata is repaired and pulled into client cache', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'server-only', label: 'server-value' })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const localValue = await model.db.values.get('server-only')
         assert.equal(localValue?.label, 'server-value')

         const localMeta = await model.db.metadata.get('server-only')
         assert.ok(localMeta?.created_at, 'client should receive repaired server metadata with a timestamp')
         assert.equal(localMeta.__dirty__, false)

         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'server-only')))[0]
         assert.ok(serverMeta?.created_at, 'server should persist repaired metadata')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('remove() creates tombstone metadata when local metadata is missing', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'orphan-local-value' })

         await model.remove('r1')

         let localMeta = await model.db.metadata.get('r1')
         assert.ok(localMeta?.deleted_at, 'remove() must create a dirty tombstone when metadata is missing')
         assert.equal(localMeta.__dirty__, true)

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         assert.ok(!await model.db.values.get('r1'), 'sync should delete the locally removed orphan value')
         localMeta = await model.db.metadata.get('r1')
         assert.ok(!localMeta, 'sync should clear tombstone metadata after acknowledging local-only delete')

         const serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(serverRows.length, 0, 'local orphan delete must not create a server row')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('update() creates dirty metadata when local metadata is missing', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'orphan-local-value' })

         await model.update('r1', { label: 'client-new' })

         let localMeta = await model.db.metadata.get('r1')
         assert.ok(localMeta?.updated_at, 'update() must create dirty metadata when metadata is missing')
         assert.equal(localMeta.__dirty__, true)

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(serverRows[0]?.label, 'client-new', 'sync should push updated orphan value to server')
         localMeta = await model.db.metadata.get('r1')
         assert.equal(localMeta.__dirty__, false, 'sync should mark pushed update clean')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('sync repairs visible local value with missing metadata and pushes it to server', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'orphan-local-value' })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(serverRows[0]?.label, 'orphan-local-value', 'sync should push visible local value even when metadata was missing')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.ok(serverMeta?.created_at, 'sync should create server metadata for repaired local value')
         const localMeta = await model.db.metadata.get('r1')
         assert.ok(localMeta?.created_at, 'sync should repair local metadata')
         assert.equal(localMeta.__dirty__, false, 'repaired local metadata should be clean after server acknowledgement')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('local value with missing metadata does not resurrect a server tombstone', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(metaTable).values({ uid: 'r1', created_at: T0, deleted_at: T1 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'stale-local-value' })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
         assert.equal(serverRows.length, 0, 'metadata repair must not resurrect a server-deleted row')
         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'r1')))[0]
         assert.equal(new Date(serverMeta.deleted_at).getTime(), T1.getTime())
         assert.ok(!await model.db.values.get('r1'), 'stale local value should be removed by server tombstone')
         assert.ok(!await model.db.metadata.get('r1'), 'repaired local metadata should be removed after tombstone wins')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('update() does not create orphan metadata when local value is missing', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         const result = await model.update('missing', { label: 'client-new' })

         assert.equal(result, undefined, 'update() should no-op when the local value is missing')
         assert.ok(!await model.db.metadata.get('missing'), 'update() must not create dirty metadata without a value')

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         assert.ok(!await model.db.metadata.get('missing'), 'sync should not leave orphan metadata for missing update')
         const serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'missing'))
         assert.equal(serverRows.length, 0, 'missing local update must not create a server row')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('remove() does not create tombstone metadata when local value is missing', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'missing', label: 'server-row' })
      await db.insert(metaTable).values({ uid: 'missing', created_at: T0 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         const result = await model.remove('missing')

         assert.equal(result, undefined, 'remove() should no-op when the local value is missing')
         assert.ok(!await model.db.metadata.get('missing'), 'remove() must not create dirty tombstone metadata without a value')

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'missing'))
         assert.equal(serverRows[0]?.label, 'server-row', 'missing local remove must not delete the server row')

         const localValue = await model.db.values.get('missing')
         assert.equal(localValue?.label, 'server-row', 'sync should pull the still-live server row')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('app-event for unregistered type is silently ignored, not TypeError', async () => {
      // When an app-event arrives for a type with no registered handler,
      // type2appHandler[type] is undefined.  The guard
      //   if (!type2appHandler[type]) type2appHandler[type] = {}
      // sets it to an empty object {}.  {} is truthy, so the next line
      //   if (handler) handler(value)
      // tries to call {} as a function → TypeError: {} is not a function.
      const received = []

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.addConnectListener(socket => {
            // Delay so the test code below can register handlers before the events fire
            setTimeout(() => {
               // First: an event for a type WITH no registered handler (triggers the bug)
               serverApp.sendAppEvent(socket.id, 'unregistered-type', 'ignored')
               // Second: an event for a type WITH a registered handler (must still work)
               serverApp.sendAppEvent(socket.id, 'registered-type', 'hello')
            }, 100)
         })
      })

      try {
         clientApp.on('registered-type', val => received.push(val))
         await new Promise(r => setTimeout(r, 400))
         assert.deepEqual(received, ['hello'],
            'registered handler must be called even after an unregistered-type event')
      } finally {
         await cleanup()
      }
   })

   test('removeDisconnectListener is callable and removes the listener', async () => {
      // removeDisonnectListener (misspelled — missing 'c') was exported on the app object
      // instead of removeDisconnectListener.  app.removeDisconnectListener is therefore
      // undefined, so any call to it throws TypeError: not a function.
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('greet', { hello: async (name) => `Hello, ${name}!` })
      })

      try {
         let callCount = 0
         const listener = () => { callCount++ }

         clientApp.addDisconnectListener(listener)

         // Must not throw — the correctly-spelled method must exist
         assert.ok(
            typeof clientApp.removeDisconnectListener === 'function',
            'removeDisconnectListener must be a function on the app object',
         )

         clientApp.removeDisconnectListener(listener)

         // After removal the listener must no longer be registered
         // (we can inspect indirectly: add a fresh listener, but the removed one
         //  should not fire — verified by callCount staying at 0)
         assert.equal(callCount, 0, 'removed listener must not have been called')
      } finally {
         await cleanup()
      }
   })

   test('addDatabase TypeError on missing fullValue does not abort remaining entries', async () => {
      // delete fullValue.uid and delete fullValue.__deleted__ are OUTSIDE the inner
      // try/catch in steps 4 and 5 of synchronize().  If idbValues.get(elt.uid)
      // returns undefined — because elt.uid is itself undefined (the clientMetadataDict
      // fallback {} has no uid property when metadata is missing) or because the record
      // was deleted from Dexie concurrently — the `delete undefined.uid` throws a
      // TypeError that escapes to the outer try/catch, aborting the entire sync and
      // silently skipping every remaining addDatabase / updateDatabase entry.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // a1: value exists in Dexie but metadata is MISSING → synchronize builds
         //     clientMetadataDict['a1'] = {} (the "should not happen" fallback)
         //     → computeSyncResult puts {} into addDatabase (elt.uid = undefined)
         //     → delete undefined.uid throws → outer catch → sync aborts
         await model.db.values.add({ uid: 'a1', label: 'no-meta' })
         // a2: normal record with both value and metadata
         await model.db.values.add({ uid: 'a2', label: 'normal' })
         await model.db.metadata.add({ uid: 'a2', created_at: T0 })

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         // a2 must be pushed despite the corrupted a1 entry aborting processing for it
         const rows = await db.select().from(modelTable)
         assert.ok(rows.find(r => r.uid === 'a2'),
            'a2 must be pushed to the server even though a1 has missing metadata')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('wherePredicate range check excludes records whose field is null', async () => {
      // The previous fix excluded undefined (NaN comparisons) but missed null.
      // JS coerces null → 0 for numeric comparisons, so for { score: { lte: 10 } }:
      //   null > 10  →  0 > 10  →  false  →  the lte guard doesn't fire
      //   → null-score record passes the filter (wrong; SQL NULL never matches ranges).
      // That record enters clientMetadataDict, appears as addDatabase to the server,
      // and if score is NOT NULL the insert fails, rolling back the Dexie record.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // Add directly to Dexie to simulate records with various score values
         await model.db.values.add({ uid: 'null-score', label: 'null', score: null })
         await model.db.values.add({ uid: 'five-score', label: 'five', score: 5 })

         // score=null should NOT match { lte: 10 } even though (null coerced to 0) <= 10
         const results = await model.findWhere({ score: { lte: 10 } })
         const uids = results.map(r => r.uid)

         assert.ok(!uids.includes('null-score'), 'null score must NOT match { lte: 10 } (SQL NULL behaviour)')
         assert.ok( uids.includes('five-score'), 'score=5 must match { lte: 10 }')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('wherePredicate range check excludes records whose field is absent (undefined)', async () => {
      // Comparing undefined with a number via >, <, >=, <= always returns false in JS
      // (undefined coerces to NaN, and NaN comparisons are always false).  So none of
      // the range return-false guards fire and a record WITHOUT the filtered field
      // incorrectly passes { score: { gte: 1 } }.  In PostgreSQL, NULL values are
      // correctly excluded by range operators, creating a client/server mismatch:
      // the client includes the record in clientMetadataDict → addDatabase → if the
      // column is NOT NULL the insert fails → rollback deletes the record from Dexie.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // r1 has no 'score' field; r2 has score=5
         await model.db.values.add({ uid: 'r1', label: 'no-score' })
         await model.db.values.add({ uid: 'r2', label: 'has-score', score: 5 })

         const results = await model.findWhere({ score: { gte: 1 } })
         const uids = results.map(r => r.uid)

         assert.ok(!uids.includes('r1'), 'record without score field must NOT match { gte: 1 }')
         assert.ok( uids.includes('r2'), 'record with score=5 must match { gte: 1 }')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('addSynchroWhere with range-operator where does not log ConstraintError when already covered', async () => {
      // isSubset uses !== (reference equality) for all values.  For primitive where
      // values (strings, numbers) this is fine.  For object values like { gte: 1 },
      // two structurally identical objects from different call sites have different
      // references, so isSubset returns false even though the where is already in the
      // list.  addSynchroDBWhere then calls whereDb.add on an already-existing key →
      // ConstraintError → caught and logged.  modified=false for the wrong reason.
      // In a real browser with persistent IndexedDB the error fires on every page load.
      const modelName = `model${++dbCounter}`
      const pglite = new PGlite()
      await pglite.exec(`
         CREATE TABLE metadata (uid TEXT PRIMARY KEY, created_at TIMESTAMP, updated_at TIMESTAMP, deleted_at TIMESTAMP);
         CREATE TABLE "${modelName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL, score INTEGER NOT NULL);
      `)
      const db = drizzle(pglite)
      const metaTable = pgTable('metadata', { uid: text('uid').primaryKey(), created_at: timestamp(), updated_at: timestamp(), deleted_at: timestamp() })
      const modelTable = pgTable(modelName, { uid: text('uid').primaryKey(), label: text('label').notNull(), score: integer('score').notNull() })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // Intercept console.log to detect spurious ConstraintError logs
         const errorLogs = []
         const origLog = console.log
         console.log = (...args) => {
            if (typeof args[0] === 'string' && args[0].startsWith('err addSynchroDBWhere')) errorLogs.push(args)
            origLog(...args)
         }

         try {
            await model.addSynchroWhere({ score: { gte: 1 } })  // first call: adds to list
            await model.addSynchroWhere({ score: { gte: 1 } })  // second call: should be detected as already covered
            assert.equal(errorLogs.length, 0, 'adding a where already in the list must not throw a ConstraintError')
         } finally {
            console.log = origLog
         }
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('compound range { gte, lte } filters consistently on both client and server', async () => {
      // wherePredicate applies `lte` first (else-if chain); whereToDrizzleFilters applies
      // `gte` first (return on first match). For { gte:1, lte:10 } this means:
      //   client includes score=0  (only lte:10 checked → 0≤10 passes)
      //   server includes score=15 (only gte:1  checked → 15≥1  passes)
      // score=0  → addDatabase → pushed to server (wrong, outside range)
      // score=15 → addClient  → added to client (wrong, outside range)
      const modelName = `model${++dbCounter}`
      const pglite = new PGlite()
      await pglite.exec(`
         CREATE TABLE metadata (uid TEXT PRIMARY KEY, created_at TIMESTAMP, updated_at TIMESTAMP, deleted_at TIMESTAMP);
         CREATE TABLE "${modelName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL, score INTEGER NOT NULL);
      `)
      const db = drizzle(pglite)
      const metaTable = pgTable('metadata', {
         uid: text('uid').primaryKey(),
         created_at: timestamp(), updated_at: timestamp(), deleted_at: timestamp(),
      })
      const modelTable = pgTable(modelName, {
         uid: text('uid').primaryKey(),
         label: text('label').notNull(),
         score: integer('score').notNull(),
      })

      // Server has records below, inside, and above the range 1–10
      await db.insert(modelTable).values([
         { uid: 'lo',  label: 'low',    score: 0  },
         { uid: 'mid', label: 'middle', score: 5  },
         { uid: 'hi',  label: 'high',   score: 15 },
      ])
      await db.insert(metaTable).values([
         { uid: 'lo',  created_at: T0 },
         { uid: 'mid', created_at: T0 },
         { uid: 'hi',  created_at: T0 },
      ])

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({ score: { gte: 1, lte: 10 } })
         await model.synchronizeAll()

         const vals = await model.db.values.toArray()
         const uids = vals.map(v => v.uid)

         assert.ok(!uids.includes('lo'),  'score=0  is below range and must NOT be in Dexie')
         assert.ok( uids.includes('mid'), 'score=5  is in range and must be in Dexie')
         assert.ok(!uids.includes('hi'),  'score=15 is above range and must NOT be in Dexie')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('whereToDrizzleFilters supports range operators used in addSynchroWhere', async () => {
      // wherePredicate (client) handles { score: { gte: 5 } } correctly after earlier fixes,
      // but whereToDrizzleFilters (server) only calls eq() for every value.
      // Passing an object like { gte: 5 } to eq() makes Drizzle try to bind a plain
      // object as a PostgreSQL parameter → query throws → sync.go catch swallows the error
      // and returns undefined → client gets a TypeError → sync silently fails.
      const modelName = `model${++dbCounter}`
      const pglite = new PGlite()
      await pglite.exec(`
         CREATE TABLE metadata (uid TEXT PRIMARY KEY, created_at TIMESTAMP, updated_at TIMESTAMP, deleted_at TIMESTAMP);
         CREATE TABLE "${modelName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL, score INTEGER NOT NULL);
      `)
      const db = drizzle(pglite)
      const metaTable = pgTable('metadata', {
         uid: text('uid').primaryKey(),
         created_at: timestamp(), updated_at: timestamp(), deleted_at: timestamp(),
      })
      const modelTable = pgTable(modelName, {
         uid: text('uid').primaryKey(),
         label: text('label').notNull(),
         score: integer('score').notNull(),
      })

      await db.insert(modelTable).values([
         { uid: 'lo', label: 'low',  score: 3 },
         { uid: 'hi', label: 'high', score: 7 },
      ])
      await db.insert(metaTable).values([
         { uid: 'lo', created_at: T0 },
         { uid: 'hi', created_at: T0 },
      ])

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({ score: { gte: 5 } })
         await model.synchronizeAll()

         const vals = await model.db.values.toArray()
         const uids = vals.map(v => v.uid)
         assert.ok(!uids.includes('lo'), 'score=3 should NOT be pulled (< 5)')
         assert.ok( uids.includes('hi'), 'score=7 should be pulled (≥ 5)')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('sync.go serializes overlapping where scopes on the server', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'x' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])

      const modelService = serverApp.service(modelName)
      const originalFindMany = modelService.__findMany
      let releaseBroadFindMany
      let broadFindManyEntered
      let narrowFindManyEntered = false
      const broadFindManyStarted = new Promise(resolve => { broadFindManyEntered = resolve })
      const broadFindManyRelease = new Promise(resolve => { releaseBroadFindMany = resolve })

      modelService.__findMany = async (context, where) => {
         if (Object.keys(where).length === 0) {
            broadFindManyEntered()
            await broadFindManyRelease
         } else {
            narrowFindManyEntered = true
         }
         return originalFindMany(context, where)
      }

      try {
         const broadSync = serverApp.service('sync').go(modelName, {}, {})
         await broadFindManyStarted

         const narrowSync = serverApp.service('sync').go(modelName, { label: 'x' }, {})
         await new Promise(resolve => setTimeout(resolve, 20))
         assert.equal(narrowFindManyEntered, false, 'narrow overlapping sync must wait for broad sync')

         releaseBroadFindMany()
         await Promise.all([broadSync, narrowSync])
         assert.equal(narrowFindManyEntered, true, 'narrow sync should run after broad sync releases')
      } finally {
         pglite.close()
      }
   })

   test('getObservable syncs persisted where scopes on a new client session', async () => {
      // If whereList was left in IndexedDB by a previous run, addSynchroDBWhere()
      // returns false. getObservable() must still sync once for this app session;
      // otherwise the first emission can be stale forever until a manual sync/reconnect.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'from-server' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.whereList.add({ sortedjson: '{}' })

         const rows = await firstValueFrom(model.getObservable({}))

         assert.deepEqual(rows.map(row => row.uid), ['r1'])
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('covered active scope remains persisted after broader scope is removed', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'open' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         await model.addSynchroWhere({})
         await model.addSynchroWhere({ label: 'open' })

         await model.db.whereList.where('sortedjson').equals('{}').delete()
         await model.db.values.clear()
         await model.db.metadata.clear()

         await model.synchronizeAll()

         const rows = await model.findWhere({ label: 'open' })
         assert.deepEqual(rows.map(row => row.uid), ['r1'])
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('scoped sync does not push dirty local rows outside the where scope', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'out', label: 'closed' })
         await model.db.metadata.add({ uid: 'out', created_at: T0, __dirty__: true })
         await model.addSynchroWhere({ label: 'open' })

         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable)
         assert.equal(serverRows.length, 0, 'scoped sync must not push dirty rows outside its where predicate')

         const localValue = await model.db.values.get('out')
         const localMeta = await model.db.metadata.get('out')
         assert.equal(localValue?.label, 'closed', 'out-of-scope local value should remain local')
         assert.equal(localMeta?.__dirty__, true, 'out-of-scope metadata should stay dirty for a matching or broad sync')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('scoped sync does not delete server rows outside the where scope', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'out', label: 'closed' })
      await db.insert(metaTable).values({ uid: 'out', created_at: T0 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'out', label: 'closed', __deleted__: true })
         await model.db.metadata.add({ uid: 'out', created_at: T0, deleted_at: T2, __dirty__: true })
         await model.addSynchroWhere({ label: 'open' })

         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'out'))
         assert.equal(serverRows[0]?.label, 'closed', 'scoped sync must not delete server rows outside its where predicate')

         const serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, 'out')))[0]
         assert.ok(!serverMeta.deleted_at, 'out-of-scope server metadata must not be tombstoned')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('disposing one offline model scope does not remove another active sync scope', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values([
         { uid: 'r1', label: 'open' },
         { uid: 'r2', label: 'closed' },
      ])
      await db.insert(metaTable).values([
         { uid: 'r1', created_at: T0 },
         { uid: 'r2', created_at: T0 },
      ])

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      const scopeA = effectScope()
      const scopeB = effectScope()

      try {
         const modelA = scopeA.run(() => clientApp.createOfflineModel(modelName, ['label']))
         const modelB = scopeB.run(() => clientApp.createOfflineModel(modelName, ['label']))

         await modelA.addSynchroWhere({ label: 'open' })
         await modelB.addSynchroWhere({ label: 'closed' })

         scopeA.stop()

         let storedScopes = []
         for (let i = 0; i < 50; i++) {
            storedScopes = (await modelB.db.whereList.toArray()).map(row => row.sortedjson).sort()
            if (!storedScopes.includes('{"label":"open"}')) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.deepEqual(storedScopes, ['{"label":"closed"}'])

         await modelB.synchronizeAll()
         const rows = await modelB.findWhere({ label: 'closed' })
         assert.deepEqual(rows.map(row => row.uid), ['r2'])
      } finally {
         scopeA.stop()
         scopeB.stop()
         await cleanup()
         pglite.close()
      }
   })

   test('initial connect syncs scopes registered while the client started offline', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'from-server' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      const socket = ioc(`http://localhost:${port}`, {
         transports: ['websocket'],
         autoConnect: false,
      })
      const clientApp = createClient(socket, { debug: false })
      offlinePlugin(clientApp)
      const model = clientApp.createOfflineModel(modelName, ['label'])
      let subscription

      try {
         await model.db.whereList.add({ sortedjson: '{}' })

         const observedServerRow = new Promise((resolve, reject) => {
            const timeout = setTimeout(() => reject(new Error('timed out waiting for synced row')), 1000)
            subscription = model.getObservable({}).subscribe({
               next: rows => {
                  if (rows.some(row => row.uid === 'r1')) {
                     clearTimeout(timeout)
                     subscription.unsubscribe()
                     resolve(rows)
                  }
               },
               error: reject,
            })
         })

         socket.connect()
         await new Promise((resolve, reject) => {
            socket.on('connect', resolve)
            socket.on('connect_error', reject)
         })

         const rows = await observedServerRow
         assert.deepEqual(rows.map(row => row.uid), ['r1'])
      } finally {
         if (subscription) subscription.unsubscribe()
         socket.disconnect()
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('reconnect flushes offline updates that moved outside the registered sync scope', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'open' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      const socket = ioc(`http://localhost:${port}`, {
         transports: ['websocket'],
         autoConnect: false,
      })
      const clientApp = createClient(socket, { debug: false })
      offlinePlugin(clientApp)
      const model = clientApp.createOfflineModel(modelName, ['label'])

      try {
         socket.connect()
         await new Promise((resolve, reject) => {
            socket.on('connect', resolve)
            socket.on('connect_error', reject)
         })

         await model.addSynchroWhere({ label: 'open' })
         await model.synchronizeAll()
         assert.equal((await model.db.values.get('r1')).label, 'open')

         socket.disconnect()
         for (let i = 0; i < 50 && clientApp.isConnected; i++) {
            await new Promise(resolve => setTimeout(resolve, 10))
         }
         assert.equal(clientApp.isConnected, false)

         await model.update('r1', { label: 'closed' })
         assert.equal((await model.db.values.get('r1')).label, 'closed')

         socket.connect()
         await new Promise((resolve, reject) => {
            socket.on('connect', resolve)
            socket.on('connect_error', reject)
         })

         let serverRows = []
         for (let i = 0; i < 50; i++) {
            serverRows = await db.select().from(modelTable).where(eq(modelTable.uid, 'r1'))
            if (serverRows[0]?.label === 'closed') break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.equal(serverRows[0]?.label, 'closed', 'durable offline mutation must be flushed even after it moved out of the query scope')
         assert.equal((await model.db.values.get('r1')).label, 'closed', 'client value must not be overwritten by stale scoped server data')
         assert.equal((await model.db.metadata.get('r1')).__dirty__, false, 'flushed out-of-scope update should be marked clean')
      } finally {
         socket.disconnect()
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('reconnect preserves updated_at for an offline create followed by offline update', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      const socket = ioc(`http://localhost:${port}`, {
         transports: ['websocket'],
         autoConnect: false,
      })
      const clientApp = createClient(socket, { debug: false })
      offlinePlugin(clientApp)
      const model = clientApp.createOfflineModel(modelName, ['label'])

      try {
         const record = await model.create({ label: 'first' })
         await model.update(record.uid, { label: 'second' })
         const localMetaBeforeConnect = await model.db.metadata.get(record.uid)
         assert.ok(localMetaBeforeConnect.created_at)
         assert.ok(localMetaBeforeConnect.updated_at)
         assert.equal(localMetaBeforeConnect.__operation__, 'create')

         socket.connect()
         await new Promise((resolve, reject) => {
            socket.on('connect', resolve)
            socket.on('connect_error', reject)
         })

         let serverRow
         let serverMeta
         for (let i = 0; i < 50; i++) {
            serverRow = (await db.select().from(modelTable).where(eq(modelTable.uid, record.uid)))[0]
            serverMeta = (await db.select().from(metaTable).where(eq(metaTable.uid, record.uid)))[0]
            if (serverRow?.label === 'second' && serverMeta?.updated_at) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.equal(serverRow?.label, 'second')
         assert.equal(new Date(serverMeta.updated_at).getTime(), new Date(localMetaBeforeConnect.updated_at).getTime())

         const localMetaAfterConnect = await model.db.metadata.get(record.uid)
         assert.equal(localMetaAfterConnect.__dirty__, false)
         assert.equal(new Date(localMetaAfterConnect.updated_at).getTime(), new Date(localMetaBeforeConnect.updated_at).getTime())
      } finally {
         socket.disconnect()
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('direct update sends the full current value to prevent partial server upserts', async () => {
      const modelName = `model${++dbCounter}`
      let receivedData

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               receivedData = data
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label', 'description'])
         await model.db.values.add({ uid: 'r1', label: 'original', description: 'must survive' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.update('r1', { label: 'patched' })
         await new Promise(resolve => setTimeout(resolve, 50))

         assert.deepEqual(receivedData, {
            label: 'patched',
            description: 'must survive',
         })
      } finally {
         await cleanup()
      }
   })

   test('stale direct update acknowledgement does not overwrite newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let firstUpdateRelease
      let updateCount = 0

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               updateCount += 1
               if (updateCount === 1) {
                  await new Promise(resolve => { firstUpdateRelease = resolve })
               }
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         model.update('r1', { label: 'first' })
         await new Promise(resolve => setTimeout(resolve, 20))
         await model.update('r1', { label: 'second' })
         firstUpdateRelease()
         await new Promise(resolve => setTimeout(resolve, 50))

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'second', 'older acknowledgement must not restore first update')
         assert.equal(meta.__dirty__, false, 'latest acknowledged update should clear dirty marker')
         assert.equal(new Date(meta.updated_at).getTime() > T0.getTime(), true)
      } finally {
         await cleanup()
      }
   })

   test('stale direct create acknowledgement does not overwrite newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let createRelease

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async (uid, data, created_at) => {
               await new Promise(resolve => { createRelease = resolve })
               return [{ uid, ...data }, { uid, created_at, updated_at: null, deleted_at: null }]
            },
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         const record = await model.create({ label: 'first' })
         await model.update(record.uid, { label: 'second' })
         createRelease()
         await new Promise(resolve => setTimeout(resolve, 50))

         const value = await model.db.values.get(record.uid)
         const meta = await model.db.metadata.get(record.uid)

         assert.equal(value.label, 'second', 'older create acknowledgement must not restore initial value')
         assert.equal(meta.__dirty__, false, 'newer acknowledged update should remain clean')
         assert.ok(meta.updated_at, 'newer update timestamp should remain')
      } finally {
         await cleanup()
      }
   })

   test('stale direct create rejection does not remove newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let createRelease

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => {
               await new Promise(resolve => { createRelease = resolve })
               throw new Error('create rejected late')
            },
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         const record = await model.create({ label: 'first' })
         await model.update(record.uid, { label: 'second' })
         createRelease()
         await new Promise(resolve => setTimeout(resolve, 50))

         const value = await model.db.values.get(record.uid)
         const meta = await model.db.metadata.get(record.uid)

         assert.equal(value.label, 'second', 'older create rejection must not remove newer local update')
         assert.ok(meta, 'metadata must remain after stale create rejection')
         assert.equal(meta.__dirty__, false, 'newer acknowledged update should remain clean')
      } finally {
         await cleanup()
      }
   })

   test('stale direct update rejection does not roll back newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let firstUpdateRelease
      let updateCount = 0

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               updateCount += 1
               if (updateCount === 1) {
                  await new Promise(resolve => { firstUpdateRelease = resolve })
                  throw new Error('first update rejected late')
               }
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         model.update('r1', { label: 'first' })
         await new Promise(resolve => setTimeout(resolve, 20))
         await model.update('r1', { label: 'second' })
         firstUpdateRelease()
         await new Promise(resolve => setTimeout(resolve, 50))

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'second', 'older rejection must not roll back the newer update')
         assert.equal(meta.__dirty__, false, 'newer acknowledged update should remain clean')
         assert.equal(new Date(meta.updated_at).getTime() > T0.getTime(), true)
      } finally {
         await cleanup()
      }
   })

   test('stale direct delete rejection does not roll back newer delete', async () => {
      const modelName = `model${++dbCounter}`
      let firstDeleteRelease
      let deleteCount = 0

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            deleteWithMeta: async (uid, deleted_at) => {
               deleteCount += 1
               if (deleteCount === 1) {
                  await new Promise(resolve => { firstDeleteRelease = resolve })
                  throw new Error('first delete rejected late')
               }
               return [{ uid, label: 'original' }, { uid, created_at: T0, deleted_at, updated_at: null }]
            },
            createWithMeta: async () => {},
            updateWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         model.remove('r1')
         await new Promise(resolve => setTimeout(resolve, 20))
         await model.remove('r1')
         firstDeleteRelease()
         await new Promise(resolve => setTimeout(resolve, 50))

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.__deleted__, true, 'older rejection must not undelete the newer delete')
         assert.ok(meta.deleted_at, 'newer delete timestamp should remain')
         assert.equal(meta.__dirty__, false, 'newer acknowledged delete should remain clean')
      } finally {
         await cleanup()
      }
   })

   test('stale direct delete acknowledgement does not overwrite newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let deleteRelease

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            deleteWithMeta: async (uid) => {
               await new Promise(resolve => { deleteRelease = resolve })
               return [{ uid, label: 'server-old' }, { uid, created_at: T0, updated_at: T1, deleted_at: null }]
            },
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         model.remove('r1')
         await new Promise(resolve => setTimeout(resolve, 20))
         await model.update('r1', { label: 'local-new' })
         deleteRelease()
         await new Promise(resolve => setTimeout(resolve, 50))

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'local-new', 'stale delete acknowledgement must not restore older server value')
         assert.equal(new Date(meta.updated_at).getTime() > T1.getTime(), true, 'newer local update timestamp must remain')
         assert.equal(meta.__dirty__, false)
      } finally {
         await cleanup()
      }
   })

   test('stale sync updateClient does not overwrite newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let resolveSyncStarted
      let releaseSync
      const syncStarted = new Promise(resolve => { resolveSyncStarted = resolve })
      const syncRelease = new Promise(resolve => { releaseSync = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => {
               resolveSyncStarted()
               await syncRelease
               return {
                  addClient: [],
                  updateClient: [[{ uid: 'r1', label: 'server-old' }, { uid: 'r1', created_at: T0, updated_at: T1, deleted_at: null }]],
                  deleteClient: [],
                  addDatabase: [],
                  updateDatabase: [],
               }
            },
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })
         await model.addSynchroWhere({})

         const syncPromise = model.synchronizeAll()
         await syncStarted
         await model.update('r1', { label: 'local-new' })
         releaseSync()
         await syncPromise

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'local-new', 'stale sync updateClient must not overwrite newer local update')
         assert.equal(meta.__dirty__, false, 'newer acknowledged update should remain clean')
         assert.equal(new Date(meta.updated_at).getTime() > T1.getTime(), true)
      } finally {
         await cleanup()
      }
   })

   test('newer sync updateClient overwrites local update made during sync', async () => {
      const modelName = `model${++dbCounter}`
      const futureUpdate = new Date(Date.now() + 60_000)
      let resolveSyncStarted
      let releaseSync
      const syncStarted = new Promise(resolve => { resolveSyncStarted = resolve })
      const syncRelease = new Promise(resolve => { releaseSync = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => {
               resolveSyncStarted()
               await syncRelease
               return {
                  addClient: [],
                  updateClient: [[
                     { uid: 'r1', label: 'server-new' },
                     { uid: 'r1', created_at: T0, updated_at: futureUpdate, deleted_at: null },
                  ]],
                  deleteClient: [],
                  addDatabase: [],
                  updateDatabase: [],
               }
            },
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })
         await model.addSynchroWhere({})

         const syncPromise = model.synchronizeAll()
         await syncStarted
         await model.update('r1', { label: 'local-new' })
         releaseSync()
         await syncPromise

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'server-new', 'newer sync updateClient must overwrite local update made during sync')
         assert.equal(new Date(meta.updated_at).getTime(), futureUpdate.getTime())
         assert.equal(meta.__dirty__, false)
      } finally {
         await cleanup()
      }
   })

   test('stale sync deleteClient does not delete newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let resolveSyncStarted
      let releaseSync
      const syncStarted = new Promise(resolve => { resolveSyncStarted = resolve })
      const syncRelease = new Promise(resolve => { releaseSync = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => {
               resolveSyncStarted()
               await syncRelease
               return {
                  addClient: [],
                  updateClient: [],
                  deleteClient: [['r1', T1]],
                  addDatabase: [],
                  updateDatabase: [],
               }
            },
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })
         await model.addSynchroWhere({})

         const syncPromise = model.synchronizeAll()
         await syncStarted
         await model.update('r1', { label: 'local-new' })
         releaseSync()
         await syncPromise

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'local-new', 'stale sync deleteClient must not delete newer local update')
         assert.ok(meta, 'metadata must remain after stale sync deleteClient')
         assert.equal(meta.__dirty__, false, 'newer acknowledged update should remain clean')
      } finally {
         await cleanup()
      }
   })

   test('newer sync deleteClient deletes local update made during sync', async () => {
      const modelName = `model${++dbCounter}`
      const futureDelete = new Date(Date.now() + 60_000)
      let resolveSyncStarted
      let releaseSync
      const syncStarted = new Promise(resolve => { resolveSyncStarted = resolve })
      const syncRelease = new Promise(resolve => { releaseSync = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async () => {
               resolveSyncStarted()
               await syncRelease
               return {
                  addClient: [],
                  updateClient: [],
                  deleteClient: [['r1', futureDelete]],
                  addDatabase: [],
                  updateDatabase: [],
               }
            },
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })
         await model.addSynchroWhere({})

         const syncPromise = model.synchronizeAll()
         await syncStarted
         await model.update('r1', { label: 'local-new' })
         releaseSync()
         await syncPromise

         assert.ok(!await model.db.values.get('r1'), 'newer sync deleteClient must delete local value changed during sync')
         const meta = await model.db.metadata.get('r1')
         assert.equal(new Date(meta.deleted_at).getTime(), futureDelete.getTime(), 'newer sync deleteClient should leave a clean tombstone guard')
         assert.equal(meta.__dirty__, false)
      } finally {
         await cleanup()
      }
   })

   test('stale sync addClient does not overwrite newer local cache row', async () => {
      const modelName = `model${++dbCounter}`
      let resolveSyncStarted
      let releaseSync
      const syncStarted = new Promise(resolve => { resolveSyncStarted = resolve })
      const syncRelease = new Promise(resolve => { releaseSync = resolve })

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('sync', {
            go: async () => {
               resolveSyncStarted()
               await syncRelease
               return {
                  addClient: [[{ uid: 'r1', label: 'server-old' }, { uid: 'r1', created_at: T1, updated_at: null, deleted_at: null }]],
                  updateClient: [],
                  deleteClient: [],
                  addDatabase: [],
                  updateDatabase: [],
               }
            },
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({})

         const syncPromise = model.synchronizeAll()
         await syncStarted
         await model.db.values.put({ uid: 'r1', label: 'local-new' })
         await model.db.metadata.put({ uid: 'r1', created_at: T2, updated_at: null, deleted_at: null, __dirty__: false })
         releaseSync()
         await syncPromise

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'local-new', 'stale sync addClient must not overwrite newer local cache row')
         assert.equal(new Date(meta.created_at).getTime(), T2.getTime(), 'newer local metadata should remain')
      } finally {
         await cleanup()
      }
   })

   test('sync addClient restores live row over equal-time local tombstone guard', async () => {
      const modelName = `model${++dbCounter}`

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService('sync', {
            go: async () => ({
               addClient: [[
                  { uid: 'r1', label: 'server-live' },
                  { uid: 'r1', created_at: T1, updated_at: null, deleted_at: null },
               ]],
               updateClient: [],
               deleteClient: [],
               addDatabase: [],
               updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.metadata.add({ uid: 'r1', created_at: T0, deleted_at: T1, __dirty__: false })
         await model.addSynchroWhere({})

         await model.synchronizeAll()

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'server-live', 'live addClient row should replace equal-time local tombstone guard')
         assert.ok(!meta.deleted_at, 'restored live row must clear local tombstone guard')
         assert.equal(new Date(meta.created_at).getTime(), T1.getTime())
      } finally {
         await cleanup()
      }
   })

   test('stale sync updateDatabase acknowledgement does not clear newer dirty update', async () => {
      const modelName = `model${++dbCounter}`
      let firstUpdateRelease
      let updateCount = 0

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async (uid, data, updated_at) => {
               updateCount += 1
               if (updateCount === 1) {
                  await new Promise(resolve => { firstUpdateRelease = resolve })
               }
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [],
               updateDatabase: [clientMetadataDict.r1],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'first' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         const syncPromise = model.synchronizeAll()
         await new Promise(resolve => setTimeout(resolve, 20))
         await model.update('r1', { label: 'second' })
         firstUpdateRelease()
         await syncPromise

         for (let i = 0; i < 50; i++) {
            const meta = await model.db.metadata.get('r1')
            if (meta?.__dirty__ === false) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'second', 'newer local value must remain after stale updateDatabase acknowledgement')
         assert.equal(new Date(meta.updated_at).getTime() > T1.getTime(), true, 'newer metadata timestamp must remain')
         assert.equal(meta.__dirty__, false, 'newer direct update acknowledgement should remain clean')
      } finally {
         await cleanup()
      }
   })

   test('stale sync addDatabase rejection does not remove newer local update', async () => {
      const modelName = `model${++dbCounter}`
      let createRelease

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => {
               await new Promise(resolve => { createRelease = resolve })
               throw new Error('stale create rejected')
            },
            updateWithMeta: async (uid, data, updated_at) => {
               return [{ uid, ...data }, { uid, created_at: T0, updated_at, deleted_at: null }]
            },
            deleteWithMeta: async () => {},
            findMany: async () => [],
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, clientMetadataDict) => ({
               addClient: [],
               updateClient: [],
               deleteClient: [],
               addDatabase: [clientMetadataDict.r1],
               updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'first' })
         await model.db.metadata.add({ uid: 'r1', created_at: T1, __dirty__: true })
         await model.addSynchroWhere({})

         const syncPromise = model.synchronizeAll()
         await new Promise(resolve => setTimeout(resolve, 20))
         await model.update('r1', { label: 'second' })
         createRelease()
         await syncPromise

         for (let i = 0; i < 50; i++) {
            const meta = await model.db.metadata.get('r1')
            if (meta?.__dirty__ === false) break
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         const value = await model.db.values.get('r1')
         const meta = await model.db.metadata.get('r1')

         assert.equal(value.label, 'second', 'stale addDatabase rejection must not remove newer local update')
         assert.ok(meta, 'metadata must remain after stale addDatabase rejection')
         assert.equal(meta.__dirty__, false, 'newer direct update acknowledgement should remain clean')
      } finally {
         await cleanup()
      }
   })

   test('update() rollback clears stale updated_at from metadata', async () => {
      // Optimistic update sets updated_at = now in metadata before the server responds.
      // On rejection the rollback does db.metadata.update(uid, previousMetadata), but
      // previousMetadata captured before the update has no updated_at key, so Dexie's
      // partial update leaves updated_at = now in place.
      // On the next sync: new Date(stale_now) - new Date(T0) > 0 → spurious updateDatabase.
      const modelName = `model${++dbCounter}`

      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            updateWithMeta: async () => { throw new Error('server rejected update') },
            createWithMeta: async () => {},
            deleteWithMeta: async () => {},
            findMany:        async () => [],
            findUnique:      async () => null,
         })
         serverApp.createService('sync', {
            go: async () => ({ addClient: [], updateClient: [], deleteClient: [], addDatabase: [], updateDatabase: [] }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })  // no updated_at

         // update() optimistically sets updated_at = now, then server rejects
         await model.update('r1', { label: 'new' })

         // Poll until the rollback restores the value
         for (let i = 0; i < 50; i++) {
            await new Promise(r => setTimeout(r, 10))
            const v = await model.db.values.get('r1')
            if (v?.label === 'original') break
         }

         assert.equal((await model.db.values.get('r1'))?.label, 'original', 'value should be rolled back')

         // updated_at must be null/undefined after rollback — a stale timestamp would
         // cause every subsequent sync to fire a spurious updateDatabase
         const meta = await model.db.metadata.get('r1')
         assert.ok(!meta.updated_at, 'updated_at should be null after rollback, not a stale timestamp')
      } finally {
         await cleanup()
      }
   })

   test('createWithMeta is idempotent: duplicate call does not erase the Dexie record', async () => {
      // Race condition: create() fires createWithMeta_A and returns immediately.
      // A concurrent synchronize() snapshots findMany() before _A lands on the server,
      // so the record appears in addDatabase.  The sync fires createWithMeta_B.
      // The server processes _A first (success), then _B hits a PK conflict on the
      // model table → throws → addDatabase catch deletes the record from Dexie.
      // Fix: model INSERT should use ON CONFLICT DO UPDATE just like the metadata INSERT.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      // Server already has r1 (createWithMeta_A already landed)
      await db.insert(modelTable).values({ uid: 'r1', label: 'original' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T0 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         // Client has r1 in Dexie from the optimistic create
         await model.db.values.add({ uid: 'r1', label: 'original' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         // Simulate createWithMeta_B: same call the addDatabase step would make
         let threw = false
         try {
            await clientApp.service(modelName).createWithMeta('r1', { label: 'original' }, T0)
         } catch (err) {
            threw = true
         }

         assert.ok(!threw, 'createWithMeta should not throw when uid already exists on server')

         // The rollback must NOT have run — r1 must still be in Dexie
         const r1 = await model.db.values.get('r1')
         assert.ok(r1, 'client Dexie should retain r1 after idempotent createWithMeta')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('addClient succeeds even when orphaned metadata already exists in Dexie', async () => {
      // The deleteWithMeta pub/sub handler does db.metadata.put(meta) which leaves
      // an orphaned metadata row after the value is deleted. If the same record is
      // later re-created on the server, addClient tries idbMetadata.add() which
      // throws a ConstraintError (PK already taken by the orphan), aborting the
      // entire addClient transaction — the record never arrives in the client cache.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      await db.insert(modelTable).values({ uid: 'r1', label: 'from-server' })
      await db.insert(metaTable).values({ uid: 'r1', created_at: T2 })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // Simulate the orphaned metadata left by a deleteWithMeta pub/sub event:
         // the value row is gone but the metadata row remains with deleted_at set.
         await model.db.metadata.add({ uid: 'r1', created_at: T0, deleted_at: T1 })

         await model.addSynchroWhere({})
         await model.synchronizeAll()

         const r1 = await model.db.values.get('r1')
         assert.ok(r1, 'r1 should be pulled into Dexie via addClient despite orphaned metadata')
         assert.equal(r1.label, 'from-server')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('wherePredicate handles boolean equality correctly', async () => {
      // typeof(true) === 'boolean', which is matched by neither the string/number branch
      // nor the null branch nor the object branch — so boolean where-values are silently
      // ignored and every record passes, sending wrong records into clientMetadataDict.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         await model.db.values.add({ uid: 'r1', label: 'active',   active: true  })
         await model.db.values.add({ uid: 'r2', label: 'inactive', active: false })

         const results = await model.findWhere({ active: true })
         const uids = results.map(r => r.uid)

         assert.ok( uids.includes('r1'), 'active=true  should match { active: true }')
         assert.ok(!uids.includes('r2'), 'active=false should NOT match { active: true }')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('wherePredicate handles null equality correctly', async () => {
      // After fixing the TypeError on null, the previous fix used `value !== null`
      // to guard the object branch — but that leaves null with NO branch at all,
      // so `where = { user_uid: null }` passes every record instead of only those
      // with user_uid === null.  In synchronize() this causes records with a non-null
      // user_uid to appear as addDatabase, hit a PK conflict, and get deleted.
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         await model.db.values.add({ uid: 'r1', label: 'with-user', user_uid: 'u1' })
         await model.db.values.add({ uid: 'r2', label: 'no-user',   user_uid: null })

         const results = await model.findWhere({ user_uid: null })
         const uids = results.map(r => r.uid)

         assert.ok(!uids.includes('r1'), 'record with user_uid=u1 should NOT match { user_uid: null }')
         assert.ok( uids.includes('r2'), 'record with user_uid=null should match { user_uid: null }')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('wherePredicate handles Date equality consistently with server sync scope', async () => {
      const modelName = `model${++dbCounter}`
      const pglite = new PGlite()
      await pglite.exec(`
         CREATE TABLE metadata (uid TEXT PRIMARY KEY, created_at TIMESTAMP, updated_at TIMESTAMP, deleted_at TIMESTAMP);
         CREATE TABLE "${modelName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL, start TIMESTAMP NOT NULL);
      `)
      const db = drizzle(pglite)
      const metaTable = pgTable('metadata', {
         uid: text('uid').primaryKey(),
         created_at: timestamp(), updated_at: timestamp(), deleted_at: timestamp(),
      })
      const modelTable = pgTable(modelName, {
         uid: text('uid').primaryKey(),
         label: text('label').notNull(),
         start: timestamp('start').notNull(),
      })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label', 'start'])
         await model.db.values.add({ uid: 'out', label: 'outside-scope', start: T2 })
         await model.db.metadata.add({ uid: 'out', created_at: T0, __dirty__: true })

         assert.deepEqual(await model.findWhere({ start: T1 }), [], 'Date equality should not match a different Date')

         await model.addSynchroWhere({ start: T1 })
         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable)
         assert.equal(serverRows.length, 0, 'Date-scoped sync must not push local rows with a different Date')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('wherePredicate handles persisted Date range bounds consistently with server sync scope', async () => {
      const modelName = `model${++dbCounter}`
      const pglite = new PGlite()
      await pglite.exec(`
         CREATE TABLE metadata (uid TEXT PRIMARY KEY, created_at TIMESTAMP, updated_at TIMESTAMP, deleted_at TIMESTAMP);
         CREATE TABLE "${modelName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL, start TIMESTAMP NOT NULL);
      `)
      const db = drizzle(pglite)
      const metaTable = pgTable('metadata', {
         uid: text('uid').primaryKey(),
         created_at: timestamp(), updated_at: timestamp(), deleted_at: timestamp(),
      })
      const modelTable = pgTable(modelName, {
         uid: text('uid').primaryKey(),
         label: text('label').notNull(),
         start: timestamp('start').notNull(),
      })

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label', 'start'])
         await model.db.values.add({ uid: 'before', label: 'before-range', start: T0 })
         await model.db.metadata.add({ uid: 'before', created_at: T0, __dirty__: true })

         const persistedWhere = { start: { gte: T1.toISOString() } }
         assert.deepEqual(await model.findWhere(persistedWhere), [], 'persisted Date range should not match a Date before the lower bound')

         await model.addSynchroWhere(persistedWhere)
         await model.synchronizeAll()

         const serverRows = await db.select().from(modelTable)
         assert.equal(serverRows.length, 0, 'Date-range sync must not push local rows outside a serialized Date lower bound')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('wherePredicate handles falsy boundary value (lte: 0) correctly', async () => {
      // wherePredicate is used by synchronize() to build clientMetadataDict.
      // A falsy boundary (lte: 0) is checked with `if (value.lte)` which treats 0
      // as "not set", causing ALL records to pass — wrong records enter clientMetadataDict
      // and the sync pushes them to the server where they fail with PK conflicts,
      // then the rollback deletes them from Dexie (data loss).
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      const { clientApp, cleanup } = await createTestContext(
         serverApp => serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable]),
         { useOfflinePlugin: true },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])

         // Dexie stores arbitrary fields — score is not indexed but is queryable
         await model.db.values.add({ uid: 'pos',  label: 'positive', score:  5 })
         await model.db.values.add({ uid: 'neg',  label: 'negative', score: -3 })
         await model.db.values.add({ uid: 'zero', label: 'zero',     score:  0 })

         const results = await model.findWhere({ score: { lte: 0 } })
         const uids = results.map(r => r.uid)

         assert.ok(!uids.includes('pos'),  'score=5  should NOT match { lte: 0 }')
         assert.ok( uids.includes('neg'),  'score=-3 should match { lte: 0 }')
         assert.ok( uids.includes('zero'), 'score=0  should match { lte: 0 }')
      } finally {
         await cleanup()
         pglite.close()
      }
   })

   test('failed addDatabase push remains dirty for retry', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async () => { throw new Error('temporary failure') },
         })
         serverApp.createService('sync', {
            go: async (_modelName, _where, metadata) => ({
               addClient: [], updateClient: [], deleteClient: [],
               addDatabase: [metadata.r1], updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true, offlinePluginImpl: localOfflinePlugin })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'offline' })
         await model.db.metadata.add({ uid: 'r1', created_at: T1, __dirty__: true })
         await model.addSynchroWhere({})
         await model.synchronizeAll()

         assert.equal((await model.db.values.get('r1'))?.label, 'offline')
         assert.equal((await model.db.metadata.get('r1'))?.__dirty__, true)
      } finally {
         await cleanup()
      }
   })

   test('failed remove restores the preceding dirty mutation', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            deleteWithMeta: async () => { throw new Error('temporary failure') },
         })
      }, { useOfflinePlugin: true, offlinePluginImpl: localOfflinePlugin })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.db.values.add({ uid: 'r1', label: 'pending update' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: T1, __dirty__: true })
         await model.remove('r1')

         for (let i = 0; i < 50 && (await model.db.values.get('r1'))?.__deleted__; i++) {
            await new Promise(resolve => setTimeout(resolve, 10))
         }

         assert.equal((await model.db.values.get('r1'))?.__deleted__ ?? null, null)
         const meta = await model.db.metadata.get('r1')
         assert.equal(new Date(meta.updated_at).getTime(), T1.getTime())
         assert.equal(meta.__dirty__, true)
      } finally {
         await cleanup()
      }
   })

   test('successive local mutations always receive increasing timestamps', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(
         () => {},
         { useOfflinePlugin: true, offlinePluginImpl: localOfflinePlugin },
      )

      try {
         clientApp.isConnected = false
         const model = clientApp.createOfflineModel(modelName, ['label'])
         const future = new Date(Date.now() + 60_000)
         await model.db.values.add({ uid: 'r1', label: 'initial' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0, updated_at: future, __dirty__: true })

         await model.update('r1', { label: 'first' })
         const first = await model.db.metadata.get('r1')
         await model.update('r1', { label: 'second' })
         const second = await model.db.metadata.get('r1')

         assert.ok(new Date(first.updated_at) > future)
         assert.ok(new Date(second.updated_at) > new Date(first.updated_at))
      } finally {
         await cleanup()
      }
   })

   test('observable unsubscribe releases its persisted synchronization scope', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(
         () => {},
         { useOfflinePlugin: true, offlinePluginImpl: localOfflinePlugin },
      )

      try {
         clientApp.isConnected = false
         const model = clientApp.createOfflineModel(modelName, ['label'])
         const subscription = model.getObservable({ label: 'open' }).subscribe(() => {})

         for (let i = 0; i < 50 && (await model.db.whereList.count()) === 0; i++) {
            await new Promise(resolve => setTimeout(resolve, 10))
         }
         assert.equal(await model.db.whereList.count(), 1)

         subscription.unsubscribe()
         for (let i = 0; i < 50 && (await model.db.whereList.count()) !== 0; i++) {
            await new Promise(resolve => setTimeout(resolve, 10))
         }
         assert.equal(await model.db.whereList.count(), 0)
      } finally {
         await cleanup()
      }
   })

   test('reset clears cached records but preserves active synchronization scopes', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(
         () => {},
         { useOfflinePlugin: true, offlinePluginImpl: localOfflinePlugin },
      )

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({ label: 'open' })
         await model.db.values.add({ uid: 'r1', label: 'open' })
         await model.db.metadata.add({ uid: 'r1', created_at: T0 })

         await model.reset()

         assert.equal(await model.db.values.count(), 0)
         assert.equal(await model.db.metadata.count(), 0)
         assert.deepEqual(
            (await model.db.whereList.toArray()).map(row => row.sortedjson),
            ['{"label":"open"}'],
         )
      } finally {
         await cleanup()
      }
   })

   test('local Drizzle plugin rejects invalid mutation timestamps', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)
      const serverApp = expressX({})
      serverApp.configure(localDrizzleOfflinePlugin, db, metaTable, [modelTable])

      try {
         await assert.rejects(
            serverApp.service(modelName).createWithMeta('r1', { label: 'invalid' }, 'not-a-date'),
            /valid timestamp/,
         )
         assert.equal((await db.select().from(modelTable)).length, 0)
      } finally {
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('Drizzle plugin requires authorization and restricts sync model names', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)
      const unauthorizedApp = expressX({})
      assert.throws(
         () => rawDrizzleOfflinePlugin(unauthorizedApp, db, metaTable, [modelTable]),
         /requires an authorize/,
      )
      unauthorizedApp.io.close()

      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])
      try {
         await assert.rejects(
            serverApp.service('sync').go('not-configured', {}, {}),
            /not configured/,
         )
      } finally {
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('same uid cannot be created in two configured models', async () => {
      const firstName = `model${++dbCounter}`
      const secondName = `model${++dbCounter}`
      const pglite = new PGlite()
      await pglite.exec(`
         CREATE TABLE metadata (uid TEXT PRIMARY KEY, created_at TIMESTAMP, updated_at TIMESTAMP, deleted_at TIMESTAMP);
         CREATE TABLE "${firstName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL);
         CREATE TABLE "${secondName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL);
      `)
      const db = drizzle(pglite)
      const metaTable = pgTable('metadata', {
         uid: text('uid').primaryKey(),
         created_at: timestamp(), updated_at: timestamp(), deleted_at: timestamp(),
      })
      const firstTable = pgTable(firstName, {
         uid: text('uid').primaryKey(), label: text('label').notNull(),
      })
      const secondTable = pgTable(secondName, {
         uid: text('uid').primaryKey(), label: text('label').notNull(),
      })
      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [firstTable, secondTable])

      try {
         await serverApp.service(firstName).createWithMeta('shared', { label: 'first' }, T0)
         await assert.rejects(
            serverApp.service(secondName).createWithMeta('shared', { label: 'second' }, T1),
            /already belongs/,
         )
      } finally {
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('concurrent cross-model creates cannot claim the same uid', async () => {
      const firstName = `model${++dbCounter}`
      const secondName = `model${++dbCounter}`
      const pglite = new PGlite()
      await pglite.exec(`
         CREATE TABLE metadata (uid TEXT PRIMARY KEY, created_at TIMESTAMP, updated_at TIMESTAMP, deleted_at TIMESTAMP);
         CREATE TABLE "${firstName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL);
         CREATE TABLE "${secondName}" (uid TEXT PRIMARY KEY, label TEXT NOT NULL);
      `)
      const db = drizzle(pglite)
      const metaTable = pgTable('metadata', {
         uid: text('uid').primaryKey(),
         created_at: timestamp(), updated_at: timestamp(), deleted_at: timestamp(),
      })
      const firstTable = pgTable(firstName, { uid: text('uid').primaryKey(), label: text('label').notNull() })
      const secondTable = pgTable(secondName, { uid: text('uid').primaryKey(), label: text('label').notNull() })
      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [firstTable, secondTable])

      try {
         const results = await Promise.allSettled([
            serverApp.service(firstName).createWithMeta('shared', { label: 'first' }, T0),
            serverApp.service(secondName).createWithMeta('shared', { label: 'second' }, T0),
         ])
         assert.equal(results.filter(result => result.status === 'fulfilled').length, 1)
         assert.equal(results.filter(result => result.status === 'rejected').length, 1)
      } finally {
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('scoped sync ignores client metadata for a real out-of-scope row', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)
      await db.insert(modelTable).values({ uid: 'closed-row', label: 'closed' })
      await db.insert(metaTable).values({ uid: 'closed-row', created_at: T1 })
      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])

      try {
         await serverApp.service('sync').go(modelName, { label: 'open' }, {
            'closed-row': { uid: 'closed-row', created_at: T0 },
         })
         assert.equal((await db.select().from(modelTable))[0]?.label, 'closed')
      } finally {
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

   test('offline plugin requires an explicit cache namespace', () => {
      const serverApp = expressX({})
      assert.throws(() => rawOfflinePlugin(serverApp), /cacheNamespace/)
      serverApp.io.close()
   })

   test('create ignores caller-controlled uid and internal deletion marker', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(() => {}, { useOfflinePlugin: true })

      try {
         clientApp.isConnected = false
         const model = clientApp.createOfflineModel(modelName, ['label'])
         const value = await model.create({ uid: 'attacker', label: 'safe', __deleted__: true })

         assert.notEqual(value.uid, 'attacker')
         assert.equal(value.__deleted__, undefined)
         assert.equal((await model.db.metadata.get(value.uid))?.uid, value.uid)
      } finally {
         await cleanup()
      }
   })

   test('malformed create acknowledgement leaves the local mutation dirty', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, { createWithMeta: async () => undefined })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         const value = await model.create({ label: 'keep' })
         await new Promise(resolve => setTimeout(resolve, 20))

         assert.equal((await model.db.values.get(value.uid))?.label, 'keep')
         assert.equal((await model.db.metadata.get(value.uid))?.__dirty__, true)
      } finally {
         await cleanup()
      }
   })

   test('mismatched sync tuple is rejected before changing the cache', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {})
         serverApp.createService('sync', {
            go: async () => ({
               addClient: [[
                  { uid: 'value-id', label: 'bad' },
                  { uid: 'metadata-id', created_at: T0 },
               ]],
               updateClient: [],
               deleteClient: [],
               addDatabase: [],
               updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({})
         await assert.rejects(() => model.synchronizeAll(), /uid/)
         assert.equal(await model.db.values.count(), 0)
         assert.equal(await model.db.metadata.count(), 0)
      } finally {
         await cleanup()
      }
   })

   test('non-JSON-safe synchronization filters are rejected', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(() => {}, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         assert.throws(() => model.addSynchroWhere({ tenant: undefined }), /non-serializable/)
         assert.throws(() => model.addSynchroWhere({ score: Number.NaN }), /non-finite/)
         assert.equal(await model.db.whereList.count(), 0)
      } finally {
         await cleanup()
      }
   })

   test('timestamp-free acknowledgement leaves mutation dirty', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {
            createWithMeta: async (uid, data) => [{ uid, ...data }, { uid }],
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         const value = await model.create({ label: 'keep' })
         await new Promise(resolve => setTimeout(resolve, 20))
         assert.equal((await model.db.metadata.get(value.uid))?.__dirty__, true)
      } finally {
         await cleanup()
      }
   })

   test('server values cannot inject the internal deletion marker', async () => {
      const modelName = `model${++dbCounter}`
      const { clientApp, cleanup } = await createTestContext(serverApp => {
         serverApp.createService(modelName, {})
         serverApp.createService('sync', {
            go: async () => ({
               addClient: [[
                  { uid: 'r1', label: 'visible', __deleted__: true },
                  { uid: 'r1', created_at: T0 },
               ]],
               updateClient: [],
               deleteClient: [],
               addDatabase: [],
               updateDatabase: [],
            }),
         })
      }, { useOfflinePlugin: true })

      try {
         const model = clientApp.createOfflineModel(modelName, ['label'])
         await model.addSynchroWhere({})
         await model.synchronizeAll()
         assert.equal((await model.findWhere({}))[0]?.label, 'visible')
      } finally {
         await cleanup()
      }
   })

   test('pub/sub createWithMeta event correctly updates a second client\'s Dexie', async () => {
      const modelName = `model${++dbCounter}`
      const { pglite, db, metaTable, modelTable } = await createTestDb(modelName)

      // Server with pub/sub: every client joins 'all' and createWithMeta broadcasts there
      const serverApp = expressX({})
      serverApp.configure(drizzleOfflinePlugin, db, metaTable, [modelTable])
      serverApp.addConnectListener(socket => serverApp.joinChannel('all', socket))
      serverApp.service(modelName).publish(async () => ['all'])
      await new Promise(resolve => serverApp.httpServer.listen(0, resolve))
      const port = serverApp.httpServer.address().port

      function connectClient() {
         const socket = ioc(`http://localhost:${port}`, { transports: ['websocket'], autoConnect: false })
         const app = createClient(socket, { debug: false })
         offlinePlugin(app)
         socket.connect()
         return new Promise((resolve, reject) => {
            socket.on('connect', () => resolve({ app, socket }))
            socket.on('connect_error', reject)
         })
      }

      const { app: appA, socket: socketA } = await connectClient()
      const { app: appB, socket: socketB } = await connectClient()

      const modelA = appA.createOfflineModel(modelName, ['label'])
      const modelB = appB.createOfflineModel(modelName, ['label'])

      try {
         // Client A creates a record while connected — fires createWithMeta directly
         const record = await modelA.create({ label: 'from-A' })

         // Poll until the pub/sub event reaches client B's Dexie
         let inB = null
         for (let i = 0; i < 50; i++) {
            await new Promise(r => setTimeout(r, 10))
            inB = await modelB.db.values.get(record.uid)
            if (inB) break
         }

         assert.ok(inB, 'Client B should receive the record via pub/sub')
         assert.equal(inB.label, 'from-A', 'Client B should have the correct label')
      } finally {
         socketA.disconnect()
         socketB.disconnect()
         await new Promise(resolve => serverApp.io.close(resolve))
         pglite.close()
      }
   })

})
