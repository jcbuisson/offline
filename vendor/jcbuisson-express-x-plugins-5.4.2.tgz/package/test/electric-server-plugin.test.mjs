import assert from 'node:assert/strict'
import test from 'node:test'
import { EventEmitter } from 'node:events'
import { Writable } from 'node:stream'
import { PGlite } from '@electric-sql/pglite'

import { electricServerPlugin, prepareElectricSyncSchema } from '../src/electric-server-plugin.mjs'

function fixture({ authorize = async () => true, fetch } = {}) {
   const services = new Map()
   const routes = new Map()
   const queries = []
   const db = {
      async query(sql, values = []) {
         queries.push({ sql, values })
         return { rows: [{ id: values.at(-1) ?? 'one', label: 'row' }] }
      },
   }
   const app = {
      createService(name, methods) { services.set(name, methods) },
      get(path, handler) { routes.set(path, handler) },
   }
   const registration = electricServerPlugin(app, db, [{ name: 'todos', primaryKey: 'id' }], { authorize, fetch: fetch ?? globalThis.fetch })
   return { app, db, services, routes, queries, registration }
}

test('registers the mutation API', async () => {
   const { services, queries } = fixture()
   const service = services.get('todos')
   assert.deepEqual(Object.keys(service), [
      'findUnique', 'findMany', 'create', 'update', 'delete',
   ])

   const value = await service.create.call({}, 'one', { label: 'new' })
   assert.equal(value.id, 'one')

   await service.create.call({}, 'only-id', {})
   assert.match(queries[1].sql, /DO UPDATE SET "id" = EXCLUDED\."id"/)
   assert.equal(queries[1].values[0], 'only-id')
   assert.deepEqual(fixture().registration.models, [
      { name: 'todos', table: 'todos', primaryKey: 'id' },
   ])
   await assert.rejects(service.create.call({}, 'bad', []), /plain object/)
})

test('allows the database to generate a primary key', async () => {
   const { services, queries } = fixture()
   const service = services.get('todos')

   await service.create.call({}, { label: 'generated id' })
   assert.match(queries[0].sql, /^INSERT INTO "todos" \("label"\) VALUES \(\$1\) RETURNING \*$/)
   assert.doesNotMatch(queries[0].sql, /ON CONFLICT/)

   await service.create.call({}, {})
   assert.equal(queries[1].sql, 'INSERT INTO "todos" DEFAULT VALUES RETURNING *')
})

test('protects the configured primary key during updates', async () => {
   const services = new Map()
   const queries = []
   const db = {
      async query(sql, values = []) {
         queries.push({ sql, values })
         return { rows: [] }
      },
   }
   const app = {
      createService(name, methods) { services.set(name, methods) },
      get() {},
   }
   electricServerPlugin(app, db, [{ name: 'people', primaryKey: 'id' }], {
      authorize: async () => true,
   })

   await services.get('people').update.call({}, 7, { id: 99, uid: 'editable', name: 'Ada' })

   assert.equal(
      queries[0].sql,
      'UPDATE "people" SET "uid" = $1, "name" = $2 WHERE "id" = $3 RETURNING *',
   )
   assert.deepEqual(queries[0].values, ['editable', 'Ada', 7])
})

test('accepts Date values in server-side filters', async () => {
   const { services, queries } = fixture()
   const createdAt = new Date('2026-08-01T12:00:00.000Z')

   await services.get('todos').findUnique.call({}, { createdAt })

   assert.equal(
      queries[0].sql,
      'SELECT * FROM "todos" WHERE "createdAt" = $1 LIMIT 1',
   )
   assert.deepEqual(queries[0].values, [createdAt])
})

test('requires authorization and reports forbidden calls', async () => {
   const { services } = fixture({ authorize: async () => false })
   await assert.rejects(
      services.get('todos').create.call({}, 'one', { label: 'no' }),
      error => error.code === 'forbidden',
   )
})

test('shape proxy pins the configured table and keeps credentials server-side', async () => {
   let fetched
   const fetch = async (url) => {
      fetched = new URL(url)
      return new Response('[{"value":{"uid":"one"}}]', {
         status: 200,
         headers: { 'content-type': 'application/json', 'electric-handle': 'abc' },
      })
   }
   const services = new Map()
   const routes = new Map()
   const db = { query: async () => ({ rows: [] }) }
   const app = {
      createService(name, methods) { services.set(name, methods) },
      get(path, handler) { routes.set(path, handler) },
   }
   electricServerPlugin(app, db, [{ name: 'todo', table: 'todos' }], {
      authorize: async () => true,
      electricUrl: 'https://electric.example/v1/shape',
      sourceId: 'source',
      sourceSecret: 'secret',
      fetch,
   })
   const response = {
      headers: {},
      status(value) { this.statusCode = value; return this },
      setHeader(key, value) { this.headers[key] = value },
      send(value) { this.body = value },
      json(value) { this.body = value },
   }
   await routes.get('/electric/v1/shape/:model')({
      params: { model: 'todo' },
      query: { table: 'secrets', offset: '10' },
      get: () => 'application/json',
   }, response, error => { throw error })

   assert.equal(fetched.searchParams.get('table'), 'todos')
   assert.equal(fetched.searchParams.get('offset'), '10')
   assert.equal(fetched.searchParams.get('source_id'), 'source')
   assert.equal(fetched.searchParams.get('secret'), 'secret')
   assert.equal(response.statusCode, 200)
   assert.equal(response.headers['electric-handle'], 'abc')
})

test('closing a shape response cancels its upstream long poll and removes its listener', async () => {
   let entered
   let signal
   const fetching = new Promise(resolve => { entered = resolve })
   const { routes } = fixture({ fetch(_url, options) {
      signal = options.signal
      entered()
      return new Promise((_resolve, reject) => {
         signal.addEventListener('abort', () => reject(new DOMException('disconnected', 'AbortError')), { once: true })
      })
   } })
   const response = new EventEmitter()
   let failure
   const handling = routes.get('/electric/v1/shape/:model')({
      params: { model: 'todos' }, query: {}, get: () => undefined,
   }, response, error => { failure = error })
   await fetching
   response.emit('close')
   await handling
   assert.equal(signal.aborted, true)
   assert.equal(failure.name, 'AbortError')
   assert.equal(response.listenerCount('close'), 0)
})

test('rejects unsafe SQL identifiers', () => {
   assert.throws(
      () => electricServerPlugin(
         { createService() {}, get() {} },
         { query() {} },
         ['todos; DROP TABLE users'],
         { authorize: async () => true, fetch: async () => {} },
      ),
      /simple SQL identifier/,
   )
})

test('sync mode commits a versioned write and rejects replayed or stale revisions', async () => {
   const queries = []
   let cursor = { revision: '0', result: null }
   let inserts = 0
   const client = {
      async query(sql, values = []) {
         queries.push({ sql, values })
         if (sql.includes('SELECT revision, result FROM electric_mutation_cursor')) return { rows: [cursor] }
         if (sql.includes('INSERT INTO "todos"')) {
            inserts++
            return { rows: [{ id: values.at(-1), version: '42', deleted: false }] }
         }
         if (sql.includes('UPDATE electric_mutation_cursor')) cursor = { revision: values[3], result: JSON.parse(values[4]) }
         return { rows: [] }
      },
      release() {},
   }
   const db = { query: client.query.bind(client), async connect() { return client } }
   const services = new Map()
   electricServerPlugin({ createService(name, methods) { services.set(name, methods) }, get() {} }, db,
      [{ name: 'todos', tombstoneData: { title: '' } }], { sync: true })
   const service = services.get('todos')
   const id = '64d76168-775f-481e-8974-18d31d835d9e'
   const clientId = '5e199e1c-23a4-473e-9989-14d4a1fb857e'
   const metadata = { clientId, revision: '2' }

   const result = await service.create.call({}, id, { title: 'first' }, metadata)
   assert.equal(result.version, '42')
   assert.equal((await service.create.call({}, id, { title: 'first' }, metadata)).version, '42')
   assert.equal((await service.create.call({}, id, { title: 'stale' }, { clientId, revision: '1' })).version, '42')
   assert.equal(inserts, 1)
   assert.equal(queries.filter(({ sql }) => sql === 'COMMIT').length, 3)
   await assert.rejects(service.create.call({}, id, { title: 'bad' }), /metadata is required/)
})

test('native BIGINT mutation values and versions remain JSON-safe and replayable', async t => {
   const pg = new PGlite()
   t.after(() => pg.close())
   await pg.exec('CREATE TABLE todos (uid UUID PRIMARY KEY, quantity BIGINT, created_at TIMESTAMPTZ DEFAULT now())')
   await prepareElectricSyncSchema(pg, ['todos'])
   const pool = { query: (...args) => pg.query(...args), async connect() {
      return { query: (...args) => pg.query(...args), release() {} }
   } }
   let service
   electricServerPlugin({ createService(_name, methods) { service = methods }, get() {} }, pool, ['todos'], { sync: true })
   const id = crypto.randomUUID()
   const clientId = crypto.randomUUID()
   const metadata = { clientId, revision: '1' }
   const result = await service.create(id, { quantity: '9007199254740993' }, metadata)
   assert.equal(result.quantity, '9007199254740993')
   assert.ok(result.created_at instanceof Date)
   assert.deepEqual(JSON.parse(JSON.stringify(await service.create(id, { quantity: '9007199254740993' }, metadata))), JSON.parse(JSON.stringify(result)))
   await pg.query("SELECT setval('electric_sync_version_seq', 9007199254740992)")
   const updated = await service.update(id, { quantity: '9007199254740995' }, { clientId, revision: '2' })
   assert.equal(updated.quantity, '9007199254740995')
   assert.equal(updated.version, '9007199254740993')
   assert.doesNotThrow(() => JSON.stringify(updated))
   const deleted = await service.delete(id, { clientId, revision: '3' })
   assert.equal(deleted.deleted, true)
   assert.equal(typeof deleted.version, 'string')
   assert.ok(BigInt(deleted.version) > BigInt(updated.version))
   assert.deepEqual(JSON.parse(JSON.stringify(await service.delete(id, { clientId, revision: '3' }))), JSON.parse(JSON.stringify(deleted)))
})

test('sync schema prepares version and tombstone columns', async () => {
   const queries = []
   await prepareElectricSyncSchema({ query: async sql => { queries.push(sql); return { rows: [] } } }, [{ name: 'todos', primaryKey: 'id' }])
   assert.equal(queries.length, 5)
   assert.match(queries[2], /ADD COLUMN IF NOT EXISTS version BIGINT/)
   assert.match(queries[3], /ADD COLUMN IF NOT EXISTS deleted BOOLEAN/)
   assert.match(queries[4], /FROM pg_constraint/)
})

test('sync delete writes a versioned tombstone and clears configured fields', async () => {
   const queries = []
   const id = '64d76168-775f-481e-8974-18d31d835d9e'
   const client = {
      async query(sql, values = []) {
         queries.push({ sql, values })
         if (sql.includes('SELECT revision, result FROM electric_mutation_cursor')) return { rows: [{ revision: '0', result: null }] }
         if (sql.includes('INSERT INTO "todos"')) return { rows: [{ id, title: '', deleted: true, version: '7' }] }
         return { rows: [] }
      },
      release() {},
   }
   const db = { query: client.query.bind(client), async connect() { return client } }
   const services = new Map()
   electricServerPlugin({ createService(name, methods) { services.set(name, methods) }, get() {} }, db,
      [{ name: 'todos', tombstoneData: { title: '' } }], { sync: true })
   const result = await services.get('todos').delete.call({}, id, {
      clientId: '5e199e1c-23a4-473e-9989-14d4a1fb857e', revision: '1',
   })
   assert.equal(result.deleted, true)
   const tombstone = queries.find(({ sql }) => sql.includes('INSERT INTO "todos"'))
   assert.match(tombstone.sql, /"title" = EXCLUDED\."title"/)
   assert.match(tombstone.sql, /version = nextval/)
   assert.deepEqual(tombstone.values, [id, ''])
})


test('sync tombstone factories generate per-row values and skip replayed revisions', async () => {
   const queries = []
   const cursors = new Map()
   const calls = []
   const client = {
      async query(sql, values = []) {
         queries.push({ sql, values })
         if (sql.includes('SELECT revision, result FROM electric_mutation_cursor')) {
            return { rows: [cursors.get(values[2]) ?? { revision: '0', result: null }] }
         }
         if (sql.startsWith('UPDATE "users"')) return { rows: [] }
         if (sql.includes('INSERT INTO "users"')) {
            return { rows: [{ uid: values[0], email: values[1], deleted: true, version: '7' }] }
         }
         if (sql.includes('UPDATE electric_mutation_cursor')) {
            cursors.set(values[2], { revision: values[3], result: JSON.parse(values[4]) })
         }
         return { rows: [] }
      },
      release() {},
   }
   const db = { query: client.query.bind(client), async connect() { return client } }
   const services = new Map()
   const app = { createService(name, methods) { services.set(name, methods) }, get() {} }
   electricServerPlugin(app, db, [{
      name: 'users', primaryKey: 'uid',
      tombstoneData: async ({ id }) => {
         calls.push(id)
         return { email: `deleted-${id}@tombstone.invalid` }
      },
   }], { sync: true })
   const service = services.get('users')
   const first = '64d76168-775f-481e-8974-18d31d835d9e'
   const second = '64d76168-775f-481e-8974-18d31d835d9f'
   const metadata = { clientId: '5e199e1c-23a4-473e-9989-14d4a1fb857e', revision: '2' }
   const result = await service.delete.call({}, first, metadata)
   assert.deepEqual(await service.delete.call({}, first, metadata), result)
   assert.deepEqual(await service.delete.call({}, first, { ...metadata, revision: '1' }), result)
   await service.update.call({}, second, { name: 'missing' }, metadata)
   await service.delete.call({}, first, { ...metadata, revision: '3' })
   assert.deepEqual(calls, [first, second, first])
   assert.deepEqual(queries.filter(({ sql }) => sql.includes('INSERT INTO "users"')).map(({ values }) => values), [
      [first, `deleted-${first}@tombstone.invalid`],
      [second, `deleted-${second}@tombstone.invalid`],
      [first, `deleted-${first}@tombstone.invalid`],
   ])
})

test('invalid tombstone factory results roll back before writing a tombstone', async () => {
   for (const [data, message] of [
      [null, /plain object/],
      [[], /plain object/],
      [{ 'email; DROP TABLE users': '' }, /simple SQL identifier/],
      [{ uid: 'override' }, /sync-managed column/],
      [{ version: '0' }, /sync-managed column/],
      [{ deleted: false }, /sync-managed column/],
   ]) {
      const queries = []
      const client = {
         async query(sql) {
            queries.push(sql)
            return { rows: sql.includes('SELECT revision, result') ? [{ revision: '0', result: null }] : [] }
         },
         release() {},
      }
      const services = new Map()
      electricServerPlugin({ createService(name, methods) { services.set(name, methods) }, get() {} },
         { query: client.query.bind(client), async connect() { return client } },
         [{ name: 'users', primaryKey: 'uid', tombstoneData: () => data }], { sync: true })
      await assert.rejects(services.get('users').delete.call({}, '64d76168-775f-481e-8974-18d31d835d9e', {
         clientId: '5e199e1c-23a4-473e-9989-14d4a1fb857e', revision: '1',
      }), message)
      assert.ok(queries.includes('ROLLBACK'))
      assert.ok(!queries.some(sql => sql.includes('INSERT INTO "users"')))
   }
})


test('server models default to the uid primary key', () => {
   const app = { createService() {}, get() {} }
   const result = electricServerPlugin(app, { query() {} }, ['users'], { authorize: async () => true })
   assert.equal(result.models[0].primaryKey, 'uid')
})


test('the Shape proxy forwards SSE events before the upstream stream closes', async () => {
   let upstream
   let wrote
   const firstWrite = new Promise(resolve => { wrote = resolve })
   const body = new ReadableStream({ start(controller) {
      upstream = controller
      controller.enqueue(new TextEncoder().encode('data: first\n\n'))
   } })
   const { routes } = fixture({ fetch: async () => new Response(body, {
      headers: { 'content-type': 'text/event-stream' },
   }) })
   const chunks = []
   const response = new Writable({ write(chunk, _encoding, done) {
      chunks.push(chunk.toString()); wrote(true); done()
   } })
   response.status = () => response
   response.setHeader = () => {}
   response.send = chunk => response.end(chunk)
   const errors = []
   const handling = routes.get('/electric/v1/shape/:model')({
      params: { model: 'todos' }, query: { live_sse: 'true' }, get: () => 'text/event-stream',
   }, response, error => errors.push(error))
   let timer
   try {
      const delivered = await Promise.race([firstWrite,
         new Promise(resolve => { timer = setTimeout(() => resolve(false), 100) }),
      ])
      assert.equal(delivered, true, 'first event must arrive while upstream remains open')
      assert.equal(chunks.join(''), 'data: first\n\n')
      upstream.enqueue(new TextEncoder().encode('data: second\n\n'))
   } finally {
      clearTimeout(timer)
      upstream.close()
      await handling
   }
   assert.equal(chunks.join(''), 'data: first\n\ndata: second\n\n')
   assert.deepEqual(errors, [])
})

test('a disconnect during authorization does not start an upstream Shape request', async () => {
   let authorize
   let entered
   const authorizing = new Promise(resolve => { entered = resolve })
   const authorization = new Promise(resolve => { authorize = resolve })
   let fetched = false
   const { routes } = fixture({
      async authorize() { entered(); return authorization },
      async fetch() { fetched = true; return new Response('[]') },
   })
   const response = new EventEmitter()
   response.status = () => response
   response.setHeader = () => {}
   response.send = () => {}
   const errors = []
   const handling = routes.get('/electric/v1/shape/:model')({
      params: { model: 'todos' }, query: {}, get: () => undefined,
   }, response, error => errors.push(error))
   await authorizing
   response.destroyed = true
   response.emit('close')
   authorize(true)
   await handling
   assert.equal(fetched, false)
   assert.equal(response.listenerCount('close'), 0)
   assert.deepEqual(errors, [])
})
