import assert from 'node:assert/strict'
import test from 'node:test'
import { PGlite } from '@electric-sql/pglite'
import { firstValueFrom } from 'rxjs'
import { electricClientPlugin } from '../src/electric-client-plugin.mjs'

class Locks {
   queues = new Map()
   request(name, { signal }, callback) {
      return new Promise((resolve, reject) => {
         const queue = this.queues.get(name) ?? []
         this.queues.set(name, queue)
         const job = { callback, resolve, reject, active: false }
         signal.addEventListener('abort', () => {
            if (job.active) return
            const index = queue.indexOf(job)
            if (index !== -1) queue.splice(index, 1)
            reject(Object.assign(new Error('aborted'), { name: 'AbortError' }))
         }, { once: true })
         queue.push(job)
         if (queue.length === 1) this.run(name)
      })
   }
   run(name) {
      const queue = this.queues.get(name)
      const job = queue[0]
      if (!job) return
      job.active = true
      Promise.resolve().then(job.callback).then(job.resolve, job.reject).finally(() => {
         queue.shift()
         this.run(name)
      })
   }
}
class Channel extends EventTarget {
   static instances = new Set()
   constructor(name) { super(); this.name = name; Channel.instances.add(this) }
   postMessage(data) {
      for (const channel of Channel.instances) {
         if (channel !== this && channel.name === this.name) channel.dispatchEvent(new MessageEvent('message', { data }))
      }
   }
   close() { Channel.instances.delete(this) }
}
class Stream {
   static instances = []
   constructor(options) { this.options = options; Stream.instances.push(this) }
   subscribe() { return () => {} }
   isConnected() { return true }
   unsubscribeAll() { this.stopped = true }
}
class Shape {
   constructor(stream) { stream.shape = this }
   subscribe(callback) { this.emit = callback; return () => {} }
}
async function until(predicate) {
   for (let i = 0; i < 100; i++) {
      if (await predicate()) return
      await new Promise(resolve => setTimeout(resolve, 5))
   }
   assert.fail('condition did not become true')
}
function configure(db, locks, service = {}, extra = {}) {
   const app = { service: () => service }
   electricClientPlugin(app, {
      sync: true, databaseName: 'test-db', localDb: db, locks,
      BroadcastChannel: Channel, ShapeStream: Stream, Shape, ...extra,
   })
   return app
}

test('managed models initialize automatically, share one database, and cache models', async () => {
   const db = new PGlite()
   let created = 0
   const locks = new Locks()
   const app = configure(undefined, locks, {}, { createDatabase: async ({ dataDir }) => {
      assert.equal(dataDir, 'idb://test-db'); created++; return db
   } })
   try {
      const users = app.createElectricModel('users')
      const customVisibility = { getCurrentState: () => 'hidden', subscribe: () => () => {} }
      const ranges = app.createElectricModel('ranges', { streamOptions: { runtimeVisibility: customVisibility, params: { test: 'preserved' } } })
      assert.equal(app.createElectricModel('users', { primaryKey: 'uid' }), users)
      assert.equal(app.createElectricModel('users'), users)
      assert.throws(() => app.createElectricModel('users', { primaryKey: 'id' }), /primaryKey/)
      const row = await users.create({ name: 'Works before prepare' })
      await ranges.prepare()
      assert.equal(created, 1)
      await until(() => Stream.instances.some(stream => stream.options.url.endsWith('/users')))
      const visibility = Stream.instances.findLast(stream => stream.options.url.endsWith('/users')).options.runtimeVisibility
      assert.equal(visibility.getCurrentState(), 'visible')
      let notified = false
      const cleanup = visibility.subscribe(() => { notified = true })
      cleanup()
      assert.equal(notified, false)
      await until(() => Stream.instances.some(stream => stream.options.url.endsWith('/ranges')))
      const rangeOptions = Stream.instances.findLast(stream => stream.options.url.endsWith('/ranges')).options
      assert.equal(rangeOptions.runtimeVisibility, customVisibility)
      assert.deepEqual(rangeOptions.params, { test: 'preserved' })
      assert.equal((await users.findUnique({ uid: row.uid })).name, row.name)
   } finally {
      await app.disposeElectricSync()
   }
   assert.equal(db.closed, true)
})

test('only one tab streams and flushes; follower edits broadcast and ownership transfers', async () => {
   const db = new PGlite()
   const locks = new Locks()
   const calls = []
   const service = { async create(id, data) { calls.push(id); return { id, ...data, version: '42' } } }
   const first = configure(db, locks, service)
   const second = configure(db, locks, service)
   const before = Stream.instances.length
   let subscription
   try {
      const owner = first.createElectricModel('todos', { primaryKey: 'id' })
      const follower = second.createElectricModel('todos', { primaryKey: 'id' })
      await owner.prepare()
      await follower.prepare()
      await until(() => Stream.instances.length === before + 1)
      let observed = []
      subscription = owner.getObservable().subscribe(rows => { observed = rows })
      const row = await follower.create({ title: 'Written in follower' })
      await until(() => calls.length === 1 && observed.length === 1)
      assert.equal(observed[0].id, row.id)
      assert.equal(Stream.instances.length, before + 1)
      const stream = Stream.instances.at(-1)
      stream.shape.emit({ rows: [{ ...row, version: 42n, deleted: false }] })
      await until(async () => (await follower.getStatus()).pending === 0)
      assert.equal((await follower.findMany())[0].version, '42')
      await owner.dispose()
      await until(() => Stream.instances.length === before + 2)
      assert.equal(stream.stopped, true)
      const next = Stream.instances.at(-1)
      next.shape.emit({ rows: [{ ...row, version: 42n, deleted: false }] })
      await until(async () => (await follower.findMany()).length === 1)
      assert.equal(calls.length, 1)
   } finally {
      subscription?.unsubscribe()
      await first.disposeElectricSync()
      await second.disposeElectricSync()
      await db.close()
   }
})

test('stopping a waiting follower cancels takeover; restart can acquire ownership', async () => {
   const db = new PGlite()
   const locks = new Locks()
   const first = configure(db, locks)
   const second = configure(db, locks)
   const before = Stream.instances.length
   try {
      const owner = first.createElectricModel('todos', { primaryKey: 'id' })
      const follower = second.createElectricModel('todos', { primaryKey: 'id' })
      await owner.prepare(); await follower.prepare()
      await until(() => Stream.instances.length === before + 1)
      follower.stop()
      owner.stop()
      await new Promise(resolve => setTimeout(resolve, 10))
      assert.equal(Stream.instances.length, before + 1)
      await follower.start()
      await until(() => Stream.instances.length === before + 2)
   } finally {
      await first.disposeElectricSync(); await second.disposeElectricSync(); await db.close()
   }
})

test('a returning sync owner preserves shared rows until its new snapshot arrives', async () => {
   const db = new PGlite()
   const locks = new Locks()
   const calls = []
   const service = {
      async create(id, data) {
         calls.push(id)
         return { id, ...data, version: '3', deleted: false }
      },
   }
   const first = configure(db, locks, service)
   const second = configure(db, locks, service)
   const before = Stream.instances.length
   const original = { id: crypto.randomUUID(), title: 'original', version: '1', deleted: false }
   const changed = { ...original, title: 'updated by next owner', version: '2' }
   const added = { id: crypto.randomUUID(), title: 'added by next owner', version: '2', deleted: false }
   try {
      const owner = first.createElectricModel('todos', { primaryKey: 'id' })
      const follower = second.createElectricModel('todos', { primaryKey: 'id' })
      await owner.prepare(); await follower.prepare()
      await until(() => Stream.instances.length === before + 1)
      Stream.instances.at(-1).shape.emit({ rows: [original] })
      await until(async () => (await owner.findMany()).length === 1)
      owner.stop()
      await until(() => Stream.instances.length === before + 2)
      Stream.instances.at(-1).shape.emit({ rows: [changed, added] })
      await until(async () => (await follower.findMany()).length === 2)

      follower.stop()
      await owner.start()
      await until(() => Stream.instances.length === before + 3)
      // Flush before the returning owner's stream delivers any snapshot.
      const created = await owner.create({ title: 'created after restart' })
      await until(async () => {
         const { rows } = await db.query('SELECT acknowledged_version FROM electric_mutation_queue WHERE row_id = $1', [created.id])
         return rows[0]?.acknowledged_version != null
      })
      assert.equal(calls.length, 1)
      assert.deepEqual(await owner.findUnique({ id: original.id }), changed)
      assert.deepEqual(await owner.findUnique({ id: added.id }), added)
      assert.equal((await owner.getStatus()).pending, 1)

      Stream.instances.at(-1).shape.emit({ rows: [changed, added, { ...created, version: '3', deleted: false }] })
      await until(async () => (await owner.getStatus()).pending === 0)
      assert.equal((await owner.findMany()).length, 3)
   } finally {
      await first.disposeElectricSync(); await second.disposeElectricSync(); await db.close()
   }
})

test('plugin disposal drains foreground writes and completes observable subscriptions before closing', async () => {
   const db = new PGlite()
   let entered
   let release
   const writing = new Promise(resolve => { entered = resolve })
   const gate = new Promise(resolve => { release = resolve })
   const app = configure(undefined, new Locks(), {}, {
      network: { onLine: false },
      createDatabase: async () => ({
         query: (...args) => db.query(...args), exec: (...args) => db.exec(...args),
         async transaction(callback) { entered(); await gate; return db.transaction(callback) },
         close: () => db.close(),
      }),
   })
   try {
      const model = app.createElectricModel('todos')
      await model.prepare()
      let completed = false
      model.getObservable().subscribe({ complete() { completed = true } })
      const created = model.create({ title: 'must finish before close' })
      await writing
      let disposed = false
      const modelDisposal = model.dispose()
      assert.equal(model.dispose(), modelDisposal)
      const pluginDisposal = app.disposeElectricSync()
      assert.equal(app.disposeElectricSync(), pluginDisposal)
      const disposing = pluginDisposal.then(() => { disposed = true })
      await Promise.resolve()
      assert.equal(completed, true)
      assert.equal(disposed, false)
      assert.equal(db.closed, false)
      release()
      assert.equal((await created).title, 'must finish before close')
      await disposing
      assert.equal(db.closed, true)
      await assert.rejects(model.create({ title: 'too late' }), /disposed/)
   } finally {
      release()
      await app.disposeElectricSync()
      if (!db.closed) await db.close()
   }
})

test('disposal during preparation keeps the channel open until accepted writes finish', async () => {
   const db = new PGlite()
   let entered
   let release
   const preparing = new Promise(resolve => { entered = resolve })
   const gate = new Promise(resolve => { release = resolve })
   let channel
   class StrictChannel extends Channel {
      closed = false
      constructor(name) { super(name); channel = this }
      postMessage(message) {
         if (this.closed) throw new DOMException('Channel is closed', 'InvalidStateError')
         return super.postMessage(message)
      }
      close() { this.closed = true; super.close() }
   }
   const app = configure({
      query: (...args) => db.query(...args), transaction: callback => db.transaction(callback),
      async exec(sql) { entered(); await gate; return db.exec(sql) },
   }, new Locks(), {}, { BroadcastChannel: StrictChannel })
   try {
      const model = app.createElectricModel('todos')
      const writing = model.create({ title: 'accepted before disposal' })
      await preparing
      const disposing = app.disposeElectricSync()
      release()
      const created = await writing
      await disposing
      assert.equal(channel.closed, true)
      assert.equal((await db.query('SELECT data FROM electric_local_rows')).rows[0].data.title, created.title)
      assert.equal((await db.query('SELECT count(*)::int AS count FROM electric_mutation_queue')).rows[0].count, 1)
   } finally {
      release()
      await app.disposeElectricSync()
      await db.close()
   }
})

test('managed observable filters are captured before readiness and subscription', async () => {
   const db = new PGlite()
   const app = configure(db, new Locks(), {}, { network: { onLine: false } })
   try {
      const model = app.createElectricModel('todos')
      const where = { score: { gte: 1, lte: 1 } }
      const observable = model.getObservable(where)
      where.score.gte = 2
      where.score.lte = 2
      await model.prepare()
      const first = await model.create({ score: 1 })
      await model.create({ score: 2 })
      assert.deepEqual((await firstValueFrom(observable)).map(row => row.uid), [first.uid])
   } finally {
      await app.disposeElectricSync()
      await db.close()
   }
})

test('initialization errors reject writes and observable reads and call onError', async () => {
   const error = new Error('Worker could not load assets')
   const reported = []
   const app = configure(undefined, new Locks(), {}, {
      createDatabase: async () => { throw error },
      onError: cause => reported.push(cause),
   })
   const model = app.createElectricModel('todos', { primaryKey: 'id' })
   await assert.rejects(model.create({ title: 'No silent failure' }), /load assets/)
   await new Promise(resolve => model.getObservable().subscribe({ error: cause => {
      assert.equal(cause, error); resolve()
   } }))
   assert.deepEqual(reported, [error])
   await assert.rejects(app.disposeElectricSync(), /load assets/)
})

test('sync mode validates browser capabilities and persistent database identity', () => {
   const app = { service: () => ({}) }
   assert.throws(() => electricClientPlugin(app, { sync: true }), /databaseName/)
   assert.throws(() => electricClientPlugin(app, { sync: true, databaseName: 'todos', locks: {} }), /Web Locks/)
})

test('default worker errors and timeouts reject preparation instead of hanging', async () => {
   for (const triggerError of [true, false]) {
      let terminated = false
      class Worker extends EventTarget {
         constructor() {
            super()
            if (triggerError) setTimeout(() => {
               const event = new Event('error')
               event.message = 'worker module not found'
               this.dispatchEvent(event)
            }, 10)
         }
         terminate() { terminated = true }
      }
      const app = configure(undefined, new Locks(), {}, { workerFactory: () => new Worker(), initTimeoutMs: 30 })
      const model = app.createElectricModel('todos', { primaryKey: 'id' })
      await assert.rejects(model.prepare(), triggerError ? /module not found/ : /timed out/)
      assert.equal(terminated, true)
      await assert.rejects(app.disposeElectricSync())
   }
})

test('snapshots and reads recover after a database leader changes', async () => {
   const db = new PGlite()
   let failSnapshot = false
   let failRead = false
   let snapshotRetries = 0
   const leaderError = () => Object.assign(new Error('Leader changed, pending operation in indeterminate state'), { name: 'LeaderChangedError' })
   const shared = {
      exec: db.exec.bind(db),
      async query(...args) {
         if (failRead) { failRead = false; throw leaderError() }
         return db.query(...args)
      },
      async transaction(callback) {
         if (failSnapshot) { failSnapshot = false; snapshotRetries++; throw leaderError() }
         return db.transaction(callback)
      },
   }
   const app = configure(shared, new Locks())
   const before = Stream.instances.length
   try {
      const model = app.createElectricModel('todos', { primaryKey: 'id' })
      await model.prepare()
      await until(() => Stream.instances.length === before + 1)
      failSnapshot = true
      const id = crypto.randomUUID()
      Stream.instances.at(-1).shape.emit({ rows: [{ id, title: 'After election', version: 99n, deleted: false }] })
      await until(async () => (await model.findMany()).length === 1)
      assert.equal(snapshotRetries, 1)
      failRead = true
      assert.equal((await model.findUnique({ id })).version, '99')
      assert.equal((await model.getStatus()).error, null)
   } finally { await app.disposeElectricSync(); await db.close() }
})

test('an indeterminate foreground mutation is not replayed automatically', async () => {
   const db = new PGlite()
   let writes = 0
   const app = { service: () => ({}) }
   const localDb = {
      exec: db.exec.bind(db), query: db.query.bind(db),
      async transaction(callback) {
         writes++
         await db.transaction(callback)
         throw Object.assign(new Error('Leader changed, pending operation in indeterminate state'), { name: 'LeaderChangedError' })
      },
   }
   electricClientPlugin(app)
   const model = app.createElectricModel('todos', { localDb, ownsSync: false })
   try {
      await model.prepare()
      await assert.rejects(model.create({ title: 'Committed but reply lost' }), /Leader changed/)
      assert.equal(writes, 1)
      assert.equal((await model.findMany()).length, 1)
      assert.equal((await model.getStatus()).pending, 1)
   } finally { await db.close() }
})

test('network lifecycle preserves offline edits, transfers ownership and respects manual stop', async () => {
   const db = new PGlite()
   const locks = new Locks()
   const events = new EventTarget()
   const network = { onLine: false }
   const calls = []
   const service = { async create(id, data) { calls.push(id); return { ...data, id, version: '1' } } }
   const first = configure(db, locks, service, { network, networkEvents: events })
   const second = configure(db, locks, service, { network, networkEvents: events })
   const before = Stream.instances.length
   let subscription
   try {
      const owner = first.createElectricModel('todos', { primaryKey: 'id' })
      const follower = second.createElectricModel('todos', { primaryKey: 'id' })
      await owner.prepare(); await follower.prepare()
      let rows = []
      subscription = follower.getObservable().subscribe(value => { rows = value })
      const created = await owner.create({ title: 'Created offline' })
      await until(() => rows.length === 1)
      assert.equal(Stream.instances.length, before)
      assert.equal(calls.length, 0)
      assert.equal((await owner.getStatus()).pending, 1)

      network.onLine = true
      events.dispatchEvent(new Event('online'))
      await until(() => Stream.instances.length === before + 1 && calls.length === 1)
      const stream = Stream.instances.at(-1)
      stream.shape.emit({ rows: [{ ...created, version: '1', deleted: false }] })
      await until(async () => (await follower.getStatus()).pending === 0)

      network.onLine = false
      events.dispatchEvent(new Event('offline'))
      await until(() => stream.stopped === true)
      await follower.update(created.id, { title: 'Updated offline' })
      assert.equal((await owner.findMany())[0].title, 'Updated offline')
      assert.equal((await follower.getStatus()).pending, 1)
      assert.equal(Stream.instances.length, before + 1)

      owner.stop()
      network.onLine = true
      events.dispatchEvent(new Event('online'))
      await until(() => Stream.instances.length === before + 2)
      follower.stop()
      await new Promise(resolve => setTimeout(resolve, 20))
      assert.equal(Stream.instances.length, before + 2, 'manually stopped owner must not take over')
      await owner.start()
      await until(() => Stream.instances.length === before + 3)
      await first.disposeElectricSync()
      await second.disposeElectricSync()
      events.dispatchEvent(new Event('offline'))
      events.dispatchEvent(new Event('online'))
      await new Promise(resolve => setTimeout(resolve, 10))
      assert.equal(Stream.instances.length, before + 3)
   } finally {
      subscription?.unsubscribe()
      await first.disposeElectricSync(); await second.disposeElectricSync(); await db.close()
   }
})

test('managed writes capture input before deferred initialization', async () => {
   const db = new PGlite()
   let release
   const gate = new Promise(resolve => { release = resolve })
   const app = configure(undefined, new Locks(), {}, { createDatabase: async () => { await gate; return db }, network: { onLine: false } })
   const model = app.createElectricModel('todos', { primaryKey: 'id' })
   try {
      const data = { title: 'accepted', details: { score: 1 } }
      const creating = model.create(data)
      data.title = 'mutated'
      data.details.score = 2
      release()
      const row = await creating
      assert.equal(row.title, 'accepted')
      assert.deepEqual(row.details, { score: 1 })
      const changes = { title: 'updated' }
      const updating = model.update(row.id, changes)
      changes.title = 'changed after invocation'
      await updating
      assert.equal((await model.findUnique({ id: row.id })).title, 'updated')
   } finally {
      release()
      await app.disposeElectricSync()
   }
})

test('an explicit start retries ownership after a failed Web Lock request', async () => {
   const db = new PGlite()
   const errors = []
   class RecoveringLocks extends Locks {
      attempts = 0
      request(...args) {
         this.attempts++
         if (this.attempts === 1) return Promise.reject(new Error('temporary lock failure'))
         return super.request(...args)
      }
   }
   const locks = new RecoveringLocks()
   const app = configure(db, locks, {}, { onError: error => errors.push(error) })
   const before = Stream.instances.length
   try {
      const model = app.createElectricModel('todos')
      await model.prepare()
      await until(() => errors.length === 1)
      assert.equal(errors[0].message, 'temporary lock failure')
      assert.equal(Stream.instances.length, before)
      await model.start()
      await until(() => Stream.instances.length === before + 1)
      assert.equal(locks.attempts, 2)
   } finally {
      await app.disposeElectricSync()
      await db.close()
   }
})

test('managed models capture configuration before deferred database initialization', async () => {
   const db = new PGlite()
   let release
   const gate = new Promise(resolve => { release = resolve })
   const app = configure(undefined, new Locks(), { async create() { return { version: '1' } } }, {
      createDatabase: async () => { await gate; return db },
   })
   const before = Stream.instances.length
   try {
      const options = { primaryKey: 'id', streamOptions: { params: { replica: 'full' } } }
      const model = app.createElectricModel('todos', options)
      const creating = model.create({ title: 'accepted before preparation' })
      options.primaryKey = 'uid'
      options.streamOptions.params.replica = 'default'
      release()
      const row = await creating
      assert.equal(typeof row.id, 'string')
      assert.equal(row.uid, undefined)
      assert.equal(app.createElectricModel('todos', { primaryKey: 'id' }), model)
      await until(() => Stream.instances.length === before + 1)
      assert.equal(Stream.instances.at(-1).options.params.replica, 'full')
      assert.equal((await model.findUnique({ id: row.id })).title, row.title)
   } finally {
      release()
      await app.disposeElectricSync()
   }
})

test('managed plugins retain the configured database when the caller reuses its options', async () => {
   const first = new PGlite(), second = new PGlite()
   const options = {
      sync: true, databaseName: 'captured-db', localDb: first, network: { onLine: false },
      locks: new Locks(), BroadcastChannel: Channel, ShapeStream: Stream, Shape,
   }
   const app = { service: () => ({}) }
   electricClientPlugin(app, options)
   try {
      options.localDb = second
      const model = app.createElectricModel('todos')
      await model.prepare()
      assert.equal((await first.query("SELECT to_regclass('electric_local_rows') IS NOT NULL AS prepared")).rows[0].prepared, true)
      assert.equal((await second.query("SELECT to_regclass('electric_local_rows') IS NOT NULL AS prepared")).rows[0].prepared, false)
   } finally {
      await app.disposeElectricSync()
      await first.close(); await second.close()
   }
})

test('managed disposal keeps caller database ownership after the options object changes', async () => {
   const db = new PGlite()
   const options = {
      sync: true, databaseName: 'caller-owned-db', localDb: db, network: { onLine: false },
      locks: new Locks(), BroadcastChannel: Channel, ShapeStream: Stream, Shape,
   }
   const app = { service: () => ({}) }
   electricClientPlugin(app, options)
   try {
      await app.createElectricModel('todos').prepare()
      delete options.localDb
      await app.disposeElectricSync()
      assert.equal(db.closed, false)
   } finally {
      await app.disposeElectricSync()
      if (!db.closed) await db.close()
   }
})
